<?php

namespace Klap\Checkout\Block\System\Config;

use Klap\Checkout\Model\HelperPasarela;
use Klap\Checkout\Model\ConfigProvider;

//Docs: https://github.com/magento/magento2/blob/2.2/app/code/Magento/Config/Block/System/Config/Form/Field.php

class DebugInfoSodexo extends \Magento\Config\Block\System\Config\Form\Field {

  private $hp;
  const SODEXO = 'klap_sodexo';

  public function __construct(
    \Magento\Backend\Block\Template\Context $context,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigInterface,
    \Magento\Framework\Module\ModuleListInterface $moduleListInterface,
    \Magento\Store\Model\StoreManagerInterface $storeManager,
    array $data = []) {
      parent::__construct($context, $data);

    $configProvider = new ConfigProvider($scopeConfigInterface, $moduleListInterface, $storeManager);
    $this->hp = new HelperPasarela($configProvider, 'MCP_',self::SODEXO);
  }

  protected function _prepareLayout() {
    parent::_prepareLayout();
    return $this;
  }

  /**
   * Render
   *
   * @param  \Magento\Framework\Data\Form\Element\AbstractElement $element
   * @return string
   */
  public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element) {
    $element->unsScope()->unsCanUseWebsiteValue()->unsCanUseDefaultValue();
    return parent::render($element);
  }

  /**
   * Get the html and scripts contents
   *
   * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
   * @return string
   */
  protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element) {
    return $this->_toHtml() . $this->hp->getDebugDataHtml();
  }
}
