<?php

namespace Klap\Checkout\Controller\KlapCheckout;

use \Magento\Framework\App\CsrfAwareActionInterface;
use \Magento\Framework\App\RequestInterface;
use \Magento\Framework\App\Request\InvalidRequestException;

/**
 * Controller que expone los webhooks y ademas procesa la redireccion desde klap checkout al ecommerce
 */
if (interface_exists("\Magento\Framework\App\CsrfAwareActionInterface")) {
  class CallbackHandler extends CallbackHandlerLegacy implements \Magento\Framework\App\CsrfAwareActionInterface {

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException {
      return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool {
      return true;
    }
  }
} else {
  class CallbackHandler extends CallbackHandlerLegacy {}
}
