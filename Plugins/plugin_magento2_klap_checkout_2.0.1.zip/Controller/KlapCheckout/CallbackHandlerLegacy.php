<?php

namespace Klap\Checkout\Controller\KlapCheckout;

use Klap\Checkout\Controller\KlapCheckout\BaseController;

use \Multicaja\Payments\Model\AmountDetails;
use \Multicaja\Payments\Model\Amount;
use \Multicaja\Payments\Model\User;
use \Multicaja\Payments\Model\Item;
use \Multicaja\Payments\Model\Custom;
use \Multicaja\Payments\Model\Urls;
use \Multicaja\Payments\Model\Webhooks;
use \Multicaja\Payments\Model\Method;
use \Multicaja\Payments\Model\Error;
use \Multicaja\Payments\Model\OrderRequest;
use \Multicaja\Payments\Model\OrderResponse;
use \Multicaja\Payments\Utils\PaymentsApiClient;
use \Multicaja\Payments\Utils\ValidateParams;

/**
 * Controller que expone los webhooks y ademas procesa la redireccion desde klap checkout al ecommerce
 */
class CallbackHandlerLegacy extends BaseController {

  const ORDERLOG = ', orderId: ';
  const PARA_ORDEN = '] para la orden, referenceId: ';
  const ORDER_ID = 'order_id';
  const FECHA = ', fecha: ';
  const DETALLE = '<h2>Detalle de Pago Klap</h2>';
  const STYLE = '<h3 style="';
  const TABLE = '</table>';
  const REFERENCE_ID = 'reference_id';
  const TOKEN_ID = 'token_id';
  const MC_CODE = 'mc_code';
  const QUOTAS_NUMBER = 'quotas_number';
  const CARD_TYPE = 'card_type';
  const LAST_DIGITS = 'last_digits';
  const PAYMENT_METHOD = 'payment_method';
  const BRAND = 'brand';
  const BIN = 'bin';
  const QUOTAS_TYPE = 'quotas_type';
  const AMOUNT = 'amount';
  const PURCHASE_DATE = 'purchase_date';
  const PAYMENT_DATE = 'payment_date';
  const NRO_CARD = 'nro_card';
  const ORDER_STATUS = 'order_status';

  public function __construct(\Magento\Framework\App\Action\Context $context,
                              \Magento\Checkout\Model\Cart $cart,
                              \Magento\Checkout\Model\Session $checkoutSession,
                              \Magento\Customer\Model\Session $customerSession,
                              \Magento\Quote\Model\QuoteManagement $quoteManagement,
                              \Magento\Store\Model\StoreManagerInterface $storeManager,
                              \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigInterface,
                              \Magento\Framework\Module\ModuleListInterface $moduleListInterface) {

    parent::__construct(
      $context, $cart, $checkoutSession, $customerSession,
      $quoteManagement, $storeManager,
      $scopeConfigInterface, $moduleListInterface);
  }

  /**
   * Metodo por defecto a implementar en los controladores de Prestashop
   */
  public function execute() {

    $paymentDate = $this->getCurrentDateTime();

    try {

      $callback = isset($_GET['mcb']) ? $_GET['mcb'] : null;

      //permite capturar la validación del webhook o url de redireccion invocada desde el administrador del plugin
      //se usa simplemente para verificr que se puede llegar a el
      $test_access = isset($_GET['test_access']) ? $_GET['test_access'] : null;
      if ($test_access === 'true') {
        if($callback === 'return_url' || $callback === 'cancel_url') {
          echo 'La url de redireccion [' . $callback . '] funciona correctamente';
        } else {
          echo 'El webhook [' . $callback . '] funciona correctamente';
        }
        die();
      }

      //maneja el callback cuando se redirecciona desde klap Checkout front a las url de la orden: return_url o cancel_url
      if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

        $referenceId = isset($_GET['referenceId']) ? $_GET['referenceId'] : null;
        $orderId = isset($_GET['orderId']) ? $_GET['orderId'] : null;

        // Pago anulado
        if ($referenceId == null || $orderId == null) {
          $this->_checkoutSession->restoreQuote();
          return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }

        if($callback !== 'return_url' && $callback !== 'cancel_url') {
          throw new \InvalidArgumentException('Error en el nombre de la url de redirección [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
        }

        $orderEcommerce = $this->getOrder($referenceId);
        $orderStatus = $orderEcommerce->getStatus();

        $this->_checkoutSession->setLastQuoteId($orderEcommerce->getQuoteId());
        $this->_checkoutSession->setLastSuccessQuoteId($orderEcommerce->getQuoteId());
        $this->_checkoutSession->setLastOrderId($orderEcommerce->getId());

        //es orden pendiente de pago
        if ($this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPendingPayment())) {

          $this->_checkoutSession->getQuote()->setIsActive(true)->save();
          $this->_checkoutSession->clearQuote();
          $this->_checkoutSession->clearStorage();
          $this->_checkoutSession->restoreQuote();
          $this->_cart->getQuote()->setIsActive(true)->save();
          $message = $this->getConfirmationOrderPage($orderEcommerce);
          $this->_messageManager->addSuccess(__($message));
          return $this->resultRedirectFactory->create()->setPath('checkout/onepage/success');

        //es orden pagada
        } else if ($this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPaid())) {

          $this->_checkoutSession->getQuote()->setIsActive(false)->save();
          $this->_checkoutSession->clearQuote();
          $this->_checkoutSession->clearStorage();
          $this->_checkoutSession->restoreQuote();
          $this->_cart->getQuote()->setIsActive(false)->save();
          $message = $this->getConfirmationOrderPage($orderEcommerce);
          $this->_messageManager->addSuccess(__($message));
          return $this->resultRedirectFactory->create()->setPath('checkout/onepage/success');

        //es orden con error en pago
        } else {
          $this->_checkoutSession->restoreQuote();
          $message = $this->getConfirmationOrderPage($orderEcommerce);
          $this->_messageManager->addError(__($message));
          return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }

      //maneja el callback cuando se invoca desde pasarela a los webhooks de la orden: webhook_confirm o webhook_reject
      } else {
        $rawPost = file_get_contents('php://input');
        $data = json_decode($rawPost, true);
        $this->logger->info('DATA WEBHOOK '.json_encode($data));

        $orderId = isset($data[self::ORDER_ID]) ? $data[self::ORDER_ID] : null;
        $referenceId = isset($data['reference_id']) ? intval($data['reference_id']) : null;

        if ($referenceId == null) {
          throw new \InvalidArgumentException('Error en la invocación del webhook [' . $callback . '] referenceId inválido');
        }

        if ($orderId == null) {
          throw new \InvalidArgumentException('Error en la invocación del webhook [' . $callback . '] orderId inválido');
        }

        if($callback !== 'webhook_confirm' && $callback !== 'webhook_reject') {
          throw new \InvalidArgumentException('Error en el nombre del webhook [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
        }

        //busca la orden en la BD del ecommerce Magento
        $orderEcommerce = $this->getOrder($referenceId);
        $this->hp->setMethod($orderEcommerce->getPayment()->getMethodInstance()->getCode());
        $apikey = $this->hp->getApiKey();
        //verifica el apikey dinamico enviado por el webhook
        $valid = ValidateParams::validateHashApiKeyFromHeaders(apache_request_headers(), $referenceId, $orderId, $apikey);

        if (!$valid) {
          throw new \InvalidArgumentException('Error en la autenticación del webhook [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        }

        //si es un pago exitoso
        if($callback === 'webhook_confirm') {
          //actualiza la orden a pagada
          $orderStatus = $this->hp->getOrderStatusPaid();

          $payment = $orderEcommerce->getPayment();
          $payment->setLastTransId($orderId);
          $payment->setTransactionId($orderId);
          $payment->setAdditionalInformation([\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => (array)json_encode($data)]);

          $orderEcommerce->setState($orderStatus)->setStatus($orderStatus);

          $quotasNumber = $data[self::QUOTAS_NUMBER] ?? null;
          $mcCode = $data[self::MC_CODE] ?? null;
          $paymentMethod =  $data[self::PAYMENT_METHOD] ?? null;
          $quotasType = null;
          if (isset($data[self::QUOTAS_TYPE])){
            $quotasType = $data[self::QUOTAS_TYPE] == 'ISSUER' ? 'Emisor' : 'Comercio';
          }
          $cardType = $data[self::CARD_TYPE] ?? null;
          if($cardType)
            $cardType = $data[self::CARD_TYPE] == "DEBIT" ?  "DÉBITO" : "CRÉDITO";
          $brand = $data[self::BRAND] ?? null;
          $lastDigits = $data[self::LAST_DIGITS] ?? null;
          $bin = $data[self::BIN] ?? null;
          $nroCard = '';
          if ($bin && $lastDigits) {
            $nroCard = $bin . '******' . $lastDigits;
          }

          $this->addMetadataToOrder($orderEcommerce, self::MC_CODE, $mcCode);
          $this->addMetadataToOrder($orderEcommerce, self::PAYMENT_DATE, $paymentDate);
          $this->addMetadataToOrder($orderEcommerce, self::PAYMENT_METHOD, $paymentMethod);
          $this->addMetadataToOrder($orderEcommerce, self::ORDER_STATUS, $orderStatus);

          if($nroCard!= '')
            $this->addMetadataToOrder($orderEcommerce, self::NRO_CARD, $nroCard);
          if($cardType)
            $this->addMetadataToOrder($orderEcommerce, self::CARD_TYPE, $cardType);
          if($brand)
            $this->addMetadataToOrder($orderEcommerce, self::BRAND, $brand);
          if($quotasNumber)
            $this->addMetadataToOrder($orderEcommerce, self::QUOTAS_NUMBER, $quotasNumber);
          if($quotasType)
            $this->addMetadataToOrder($orderEcommerce, self::QUOTAS_TYPE, $quotasType);

          $this->logger->info('Pago realizado con exito usando [Klap - Checkout'. self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        } else {
          //actualiza la orden a fallida
          $orderStatus = $this->hp->getOrderStatusFailed();
          $orderEcommerce->setState($orderStatus)->setStatus($orderStatus);
          $this->logger->error('Pago rechazado o anulado usando [Klap - Checkout'. self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        }

        $orderEcommerce->save();
        header('HTTP/1.1 200 OK');
        die();
      }
    } catch(\Exception $ex) {
      $this->logger->error($ex->getMessage() . self::FECHA . $paymentDate, $ex);
      header('HTTP/1.1 500 Internal Server Error');
      die();
    }
  }

  /**
   * Crea la pagina resultado del pago
   */
  private function getConfirmationOrderPage($orderEcommerce) {
    $referenceId = $orderEcommerce->getId();
    $messages = $orderEcommerce->getAllStatusHistory();
    $amount = $this->getMetadataFromOrder($messages, self::AMOUNT);
    $orderId = $this->getMetadataFromOrder($messages, self::ORDER_ID);
    $purchaseDate = $this->getMetadataFromOrder($messages, self::PURCHASE_DATE);
    $paymentDate = $this->getMetadataFromOrder($messages, self::PAYMENT_DATE);
    $orderStatus = $orderEcommerce->getStatus();
    $data ='';
    //por defecto es orden con error
    if($referenceId)
      $data =
      '<tr>
        <td>Order ID Klap Checkout:</td>
        <td id="mcp-order-id">'. $orderId .'</td>
      </tr>
      <tr>
        <td>Id de orden:</td>
        <td>'. $referenceId .'</td>
      </tr>
      <tr>
        <td>Monto transacción:</td>
        <td>$ '. $amount . '</td>
      </tr>';

    //es orden pagada
    if ($this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPaid())) {

      $mcCode = $this->getMetadataFromOrder($messages, self::MC_CODE);
      $cardType = $this->getMetadataFromOrder($messages, self::CARD_TYPE);
      $brand = $this->getMetadataFromOrder($messages, self::BRAND);
      $nroCard = $this->getMetadataFromOrder($messages, self::NRO_CARD);
      $paymentMethod = $this->getMetadataFromOrder($messages, self::PAYMENT_METHOD);

      if($mcCode)
        $data = $data .
         '<tr>
           <td>Mc Code:</td>
           <td>'. $mcCode .'</td>
          </tr>
          <tr>
            <td>Fecha y hora de pago:</td>
            <td>'. date('d-m-Y H:i', strtotime($paymentDate)).'</td>
          </tr>';

      $isTarjeta = $cardType || $brand  || $nroCard;

      if($isTarjeta){
        $quotas_type = $this->getMetadataFromOrder($messages, self::QUOTAS_TYPE);
        $quotas_number = $this->getMetadataFromOrder($messages, self::QUOTAS_NUMBER);

        $data = $data .
        '<tr>
          <td>Tarjeta:</td>
          <td>'. $nroCard .'</td>
        </tr>
        <tr>
          <td>Tipo de tarjeta:</td>
          <td>'. $cardType .'</td>
        </tr>
        <tr>
          <td>Marca Tarjeta:</td>
          <td>'. $brand .'</td>
        </tr>';
        if($cardType != "DÉBITO"){
          $data = $data .
          '<tr>
            <td>Tipo de cuotas:</td>
            <td>'. $quotas_type .'</td>
          </tr>
          <tr>
            <td>Cantidad cuota:</td>
            <td>'. $quotas_number .'</td>
          </tr>';
        }
      }

      $data = $data .
      '<tr>
        <td>Método de pago:</td>
        <td>'. $paymentMethod .'</td>
      </tr>';
      $style = 'background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; border-radius: 5px; padding: 10px;';

      $respHtml = 'Estimado cliente, su orden ha sido recibida y pagada exitosamente' .
      self::DETALLE .
      self::STYLE . $style . '">Pago realizado con éxito usando Klap</h3><table><tbody>' . $data .'</tbody>'. self::TABLE;

    //es orden pendiente de pago
    } else if ($this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPendingPayment())) {

      $style = 'background-color: #fff3cd; border: 1px solid #ffeeba; color: #856404; border-radius: 5px; padding: 10px;';

      $refreshUrl = $this->hp->getReturnUrl() . '&referenceId=' . $referenceId . '&orderId=' . $orderId;

      $data = $data  .
          '<tr>
            <td>Fecha y hora de pedido:</td>
            <td>'.date('d-m-Y H:i', strtotime($purchaseDate)).'</td>
           </tr>
           <tr>
            <td colspan="2">
              <a href="' . $refreshUrl . '">Actualizar Orden</a>
            </td>
           </tr>';

      $respHtml = 'Estimado cliente, su orden ha sido recibida pero el pago se encuentra pendiente' .
      self::DETALLE .
      self::STYLE . $style . '">Orden pendiente de pago - <a href="' . $refreshUrl . '" style="color:#0747A6;">Actualizar Orden</a></h3>
      <table><tbody>' . $data . '</tbody>'.self::TABLE;
    } else {

      $data = $data  .
      '<tr>
        <td>Fecha y hora de pedido:</td>
        <td>'.date('d-m-Y H:i', strtotime($purchaseDate)).'</td>
      </tr>';

      $style = 'background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; border-radius: 5px; padding: 10px;';

      $respHtml = 'Estimado cliente, el pago de su orden ha fallado' .
      self::DETALLE .
      self::STYLE . $style . '">Error en el pago</h3><table><tbody>' . $data .'</tbody>'.self::TABLE;
    }

    return $respHtml;
  }

}
