<?php

namespace Klap\Checkout\Controller\KlapCheckout;

use \Magento\Framework\App\CsrfAwareActionInterface;
use \Magento\Framework\App\RequestInterface;
use \Magento\Framework\App\Request\InvalidRequestException;

/**
 * Controller para crear la orden y redireccionar a klap checkout
 */
if (interface_exists("\Magento\Framework\App\CsrfAwareActionInterface")) {
  class CreateOrder extends CreateOrderLegacy implements \Magento\Framework\App\CsrfAwareActionInterface {

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException {
      return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool {
      return true;
    }
  }
} else {
  class CreateOrder extends CreateOrderLegacy {}
}
