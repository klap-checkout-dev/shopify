<?php

namespace Klap\Checkout\Model;

use \Magento\Sales\Model\Order;
use \Magento\Checkout\Model\ConfigProviderInterface;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Framework\Module\ModuleListInterface;
use \Magento\Store\Model\StoreManagerInterface;

class ConfigProvider implements ConfigProviderInterface {

  public function __construct(ScopeConfigInterface $scopeConfigInterface,
                              ModuleListInterface $moduleListInterface,
                              StoreManagerInterface $storeManager) {
    $this->_scopeConfigInterface = $scopeConfigInterface;
    $this->_moduleListInterface = $moduleListInterface;
    $this->_storeManager = $storeManager;
  }

  public function getConfig() {
    return [
      'pluginConfig' => []
    ];
  }

  /**
   * Devuelve informacion propia del ecommerce, usado por HelperPasarela
   */
  public function getEcommerceData() {
    $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
    if (!$this->endsWith($baseUrl, '/')) {
      $baseUrl.='/';
    }
    return array(
      'pluginVersion' => $this->getPluginVersion(),
      'ecommerceInfo' => 'magento-' . $this->getMagentoVersion(),
      'webhooksBaseUrl' => $baseUrl . 'checkout/klapcheckout/callbackhandler',
      'orderStatusPendingPayment' => Order::STATE_PENDING_PAYMENT,
      'orderStatusPaid' => Order::STATE_PROCESSING,
      'orderStatusFailed' => Order::STATE_CANCELED
    );
  }

  /**
   * Devuelve un valor de una configuracion, usado por HelperPasarela
   */
  public function getConfigValue($method_, $key, $defaultValue) {
    $value = $this->_scopeConfigInterface->getValue('payment/'.$method_.'/' . $key);
    return $value == '' || $value == null ? $defaultValue : $value;
  }

  /**
   * Retorna la version del plugin
   */
  private function getPluginVersion() {
    return $this->_moduleListInterface->getOne('Klap_Checkout')['setup_version'];
  }

  /**
   * Retorna la version de magento
   */
  private function getMagentoVersion() {
    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $productMetadata = $objectManager->get('Magento\Framework\App\ProductMetadataInterface');
    return $productMetadata->getVersion();
  }

  private function endsWith($haystack, $needle) {
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }
    return (substr($haystack, -$length) === $needle);
  }
}
