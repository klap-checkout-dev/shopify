<?php

namespace Klap\Checkout\Model\Config;

class EfectivoNotifyUser implements \Magento\Framework\Option\ArrayInterface {

  /**
   * Options getter
   *
   * @return array
   */
  public function toOptionArray() {
    return [
      ['value' => 'true', 'label' => 'Klap'],
      ['value' => 'false', 'label' => 'Comercio']
    ];
  }
}
