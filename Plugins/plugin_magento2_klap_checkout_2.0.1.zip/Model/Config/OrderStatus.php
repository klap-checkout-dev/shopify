<?php

namespace Klap\Checkout\Model\Config;

use \Magento\Sales\Model\Order;

// docs: https://github.com/magento/magento2/blob/2.2/app/code/Magento/Sales/Model/Order.php

class OrderStatus implements \Magento\Framework\Option\ArrayInterface {

  const VALUE = 'value';
  const LABEL = 'label';
  /**
   * Options getter
   *
   * @return array
   */
  public function toOptionArray() {
    return [
      [self::VALUE => Order::STATE_NEW, self::LABEL => Order::STATE_NEW],
      [self::VALUE => Order::STATE_PENDING_PAYMENT, self::LABEL => Order::STATE_PENDING_PAYMENT],
      [self::VALUE => Order::STATE_PROCESSING, self::LABEL => Order::STATE_PROCESSING],
      [self::VALUE => Order::STATE_COMPLETE, self::LABEL => Order::STATE_COMPLETE],
      [self::VALUE => Order::STATE_CANCELED, self::LABEL => Order::STATE_CANCELED],
      [self::VALUE => Order::STATE_CLOSED, self::LABEL => Order::STATE_CLOSED],
      [self::VALUE => Order::STATE_PAYMENT_REVIEW, self::LABEL => Order::STATE_PAYMENT_REVIEW]
    ];
  }
}
