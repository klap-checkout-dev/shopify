<?php

namespace Klap\Checkout\Model\Config;

class Environments implements \Magento\Framework\Option\ArrayInterface {

  const VALUE = 'value';
  const LABEL = 'label';
  /**
   * Options getter
   *
   * @return array
   */
  public function toOptionArray() {
    if ($this->isLocalDev()) {
      return [
        [self::VALUE => 'local', self::LABEL => 'Local'],
        [self::VALUE => 'integration', self::LABEL => 'Integración'],
        [self::VALUE => 'production', self::LABEL => 'Producción']
      ];
    } else {
      return [
        [self::VALUE => 'integration', self::LABEL => 'Integración'],
        [self::VALUE => 'production', self::LABEL => 'Producción']
      ];
    }
  }

  public function isLocalDev() {
    return getenv('IS_LOCAL_DEV') == 'true';
  }
}
