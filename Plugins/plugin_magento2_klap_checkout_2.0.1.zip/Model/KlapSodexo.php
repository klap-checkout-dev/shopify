<?php

namespace Klap\Checkout\Model;

use Klap\Checkout\Model\KlapCheckoutBase;

define('MCP_PLUGIN_VERSION_SODEXO', '2.0.1');

/**
 * Pay In Store payment method model
 */
class KlapSodexo extends KlapCheckoutBase {

  /**
   * Payment code
   *
   * @var string
   */
  protected $_code = 'klap_sodexo';
}
