define(
  [
    'jquery',
    'Magento_Checkout/js/view/payment/default'
  ],
  function ($,
    Component,
    placeOrderAction,
    selectPaymentMethodAction,
    customer,
    checkoutData,
    additionalValidators,
    url,
    quote) {
    'use strict';

    return Component.extend({
      defaults: {
        template: 'Klap_Checkout/payment/klap_checkout'
      },
      getCode: function() {
        return 'klap_efectivo_transferencia';
      },
      getTitle: function() {
        return "Paga con Efectivo Klap y/o Transferencia";
      },
      getDescription: function() {
        return "Paga en efectivo en comercios Klap, Caja Los Héroes, Turbus o Starken. O puedes transferir desde tu cuenta bancaria.";
      },
      getImg: function() {
        return "https://i.ibb.co/52n3h83/logo-klap.png";
      },
      placeOrder: function() {
        var guestEmail = undefined;
        if (quote && quote.guestEmail) {
          guestEmail = quote.guestEmail;
        }
        if (guestEmail == undefined || guestEmail == '') {
          guestEmail = $('#customer-email').val();
        }
        var endpoint = './klapcheckout/createorder?method=klap_efectivo_transferencia';
        if (guestEmail != undefined) {
          endpoint+='&guestEmail=' + encodeURIComponent(guestEmail);
        }
        location.href = endpoint;
      }
    })
  }
);
