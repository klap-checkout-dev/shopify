define(
  [
    'uiComponent',
    'Magento_Checkout/js/model/payment/renderer-list'
  ],
  function (Component, rendererList) {
    'use strict';
    rendererList.push(
      {
        type: 'klap_tarjetas',
        component: 'Klap_Checkout/js/view/payment/method-renderer/klap_tarjetas-method'
      },
      {
        type: 'klap_sodexo',
        component: 'Klap_Checkout/js/view/payment/method-renderer/klap_sodexo-method'
      },
      {
        type: 'klap_efectivo_transferencia',
        component: 'Klap_Checkout/js/view/payment/method-renderer/klap_efec_trans-method'
      }
    );
    // View logic goes here!
    return Component.extend({});
  }
);
