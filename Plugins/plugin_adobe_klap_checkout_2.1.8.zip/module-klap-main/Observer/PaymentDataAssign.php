<?php

namespace Improntus\Klap\Observer;

use Magento\Framework\Event\Observer;
use Magento\Payment\Observer\AbstractDataAssignObserver;
use Magento\Quote\Api\Data\PaymentInterface;

/**
 * Class PaymentDataAssign adds the klap order id to the place order getData
 */
class PaymentDataAssign extends AbstractDataAssignObserver
{
    public const KLAP_ORDER_ID = 'order_id';

    /**
     * Additional information for getData
     *
     * @var array
     */
    protected $additionalInformationList = [
        self::KLAP_ORDER_ID,
    ];

    /**
     * Execute Class to add additional data
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $data = $this->readDataArgument($observer);
        $additionalData = $data->getData(PaymentInterface::KEY_ADDITIONAL_DATA);
        if (!is_array($additionalData)) {
            return;
        }
        $paymentInfo = $this->readPaymentModelArgument($observer);
        foreach ($this->additionalInformationList as $additionalInformationKey) {
            if (isset($additionalData[$additionalInformationKey])) {
                $paymentInfo->setAdditionalInformation(
                    $additionalInformationKey,
                    $additionalData[$additionalInformationKey]
                );
            }
        }
    }
}
