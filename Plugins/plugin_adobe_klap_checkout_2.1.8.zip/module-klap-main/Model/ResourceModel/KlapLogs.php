<?php

namespace Improntus\Klap\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class KlapLogs extends AbstractDb
{
    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init('klap_logs', 'entity_id');
    }
}
