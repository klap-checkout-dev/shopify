<?php

namespace Improntus\Klap\Model;

use Improntus\Klap\Api\Data\TransactionInterface;
use Magento\Framework\Model\AbstractModel;

/**
 * Transaction Model
 */
class Transaction extends AbstractModel implements TransactionInterface
{

    /**
     * Constructor
     *
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Improntus\Klap\Model\ResourceModel\Transaction::class);
    }

    /**
     * Retrieves table ID value
     *
     * @return int|string|null
     */
    public function getTransactionId()
    {
        return $this->getData(self::TRANSACTION_ID);
    }

    /**
     * Sets table ID value
     *
     * @param $transactionId
     * @return TransactionInterface|Transaction
     */
    public function setTransactionId($transactionId)
    {
        return $this->setData(self::TRANSACTION_ID, $transactionId);
    }

    /**
     * Gets Order ID Value from transaction
     *
     * inherit phpdoc
     */
    public function getOrderId()
    {
        return $this->getData(self::ORDER_ID);
    }

    /**
     * Sets Order ID Value for transaction
     *
     * inherit phpdoc
     */
    public function setOrderId($orderId)
    {
        return $this->setData(self::ORDER_ID, $orderId);
    }

    /**
     * Gets Klap's order_id from transaction
     *
     * inherit phpdoc
     */
    public function getKlapTransactionId()
    {
        return $this->getData(self::KLAP_TRANSACTION_ID);
    }

    /**
     * Sets Klap's order_id for transaction
     *
     * inherit phpdoc
     */
    public function setKlapTransactionId($klapTransactionId)
    {
        return $this->setData(self::KLAP_TRANSACTION_ID, $klapTransactionId);
    }

    /**
     * Gets current transaction status
     *
     * inherit phpdoc
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * Sets current transaction status
     *
     * inherit phpdoc
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * Gets created_at data from row
     *
     * inherit phpdoc
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Sets created_at data for row
     *
     * inherit phpdoc
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Gets expired_at data from row
     *
     * inherit phpdoc
     */
    public function getExpiredAt()
    {
        return $this->getData(self::EXPIRED_AT);
    }

    /**
     * Sets expired_at data for row
     *
     * inherit phpdoc
     */
    public function setExpiredAt($expiredAt)
    {
        return $this->setData(self::EXPIRED_AT, $expiredAt);
    }

    /**
     * Gets foreign key quote_id from transaction row
     *
     * inherit phpdoc
     */
    public function getQuoteId()
    {
        return $this->getData(self::QUOTE_ID);
    }

    /**
     * Sets foreign key quote_if for transaction row
     *
     * inherit phpdoc
     */
    public function setQuoteId($quoteId)
    {
        return $this->setData(self::QUOTE_ID, $quoteId);
    }

    /**
     * Gets increment_id value from transaction
     *
     * inherit phpdoc
     */
    public function getIncrementId()
    {
        return $this->getData(self::KLAP_INCREMENT_ID);
    }

    /**
     * Sets Increment ID for transaction
     *
     * inherit phpdoc
     */
    public function setIncrementId($incrementId)
    {
        return $this->setData(self::KLAP_INCREMENT_ID, $incrementId);
    }
}
