<?php

namespace Improntus\Klap\Model\Config\Source;

use Improntus\Klap\Helper\Data;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Payment Method Class returns specific payment values
 */
class PaymentMethod implements OptionSourceInterface
{

    /**
     * @var Data
     */
    private $klapHelper;

    /**
     * Construct function
     *
     * @param Data $klapHelper
     */
    public function __construct(
        Data $klapHelper
    ) {
        $this->klapHelper = $klapHelper;
    }

    /**
     * Returns option data
     *
     * @return array[]
     * @throws NoSuchEntityException
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => __('Klap'),
                'value' => 'klap',
                'payment' => [
                    'klap' => [
                        'redirect_url' => $this->klapHelper->getRedirectUrl(),
                        'error_url' => $this->klapHelper->getFailUrl(),
                        'origin_url' => $this->klapHelper->getOriginUrl()
                    ]
                ],
            ]
        ];
    }
}
