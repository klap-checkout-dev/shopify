<?php

namespace Improntus\Klap\Model;

use Improntus\Klap\Model\ResourceModel\KlapLogs as KlapLogsResource;
use Improntus\Klap\Model\ResourceModel\KlapLogs\CollectionFactory as KlapCollection;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Stdlib\DateTime;
use Magento\Framework\Serialize\Serializer\Json;
use Improntus\Klap\Model\Rest\Connector;

class KlapLogsRepository
{

    /**
     * @var KlapLogs
     */
    private $klapLogs;

    /**
     * @var KlapLogsResource
     */
    private $klapLogsResource;

    /**
     * @var DateTime
     */
    private $dateTime;

    /**
     * @var Json
     */
    private $serializer;

    /**
     * @var Connector
     */
    private $connector;

    /**
     * @var KlapCollection
     */
    private $collection;

    /**
     * @param KlapLogs $klapLogs
     * @param KlapLogsResource $klapLogsResource
     * @param DateTime $dateTime
     * @param Json $serializer
     * @param Connector $connector
     * @param KlapCollection $collection
     */
    public function __construct(
        KlapLogs         $klapLogs,
        KlapLogsResource $klapLogsResource,
        DateTime         $dateTime,
        Json             $serializer,
        Connector        $connector,
        KlapCollection   $collection
    ) {
        $this->dateTime = $dateTime;
        $this->klapLogs = $klapLogs;
        $this->klapLogsResource = $klapLogsResource;
        $this->serializer = $serializer;
        $this->connector = $connector;
        $this->collection = $collection;
    }

    /**
     * @inheritDoc
     */
    public function save(KlapLogs $klapLogs)
    {
        try {
            $this->klapLogsResource->save($klapLogs);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the transaction: %1',
                $exception->getMessage()
            ));
        }
        return $klapLogs;
    }

    /**
     * @inheritDoc
     */
    public function saveLogResponse($data)
    {
        $status = '';
        if (isset($data->order_id)) {
            $wsResponse = $this->connector->checkOrderByKlapId($data->order_id);
            if (array_key_exists("status", $wsResponse)) {
                $status = $wsResponse["status"] !== "pending" ?
                    $wsResponse["status"] : $data->status ?? $wsResponse["status"];
            } else {
                $status = $data->status ?? '';
            }
        }
        $klapLog = $this->klapLogs;
        $klapLog->setKlapTransactionId($data->order_id ?? '');
        $klapLog->setStatus($status);
        $klapLog->setRawResponse($this->serializer->serialize($data));
        $klapLog->setCreatedAt($this->dateTime->formatDate(true));
        $this->save($klapLog);
    }

    /**
     * Deletes historical logs that are above 6 months
     *
     * inherit phpdoc
     */
    public function deleteOlderLogs()
    {
        $timeZone = new \DateTimeZone('America/Santiago');
        $currentTime = date_create(date('Y-m-d H:i:s', strtotime("now")), $timeZone);
        $currentTime->sub(\DateInterval::createFromDateString('6 months'));
        $klapCollection = $this->collection->create();
        $klapCollection->getSelect()
            ->where('created_at <= "' . $this->dateTime->formatDate($currentTime) . '"');
        foreach ($klapCollection as $oldLog) {
            $this->klapLogsResource->delete($oldLog);
        }
    }
}
