<?php

namespace Improntus\Klap\Model;

use Exception;
use Improntus\Klap\Api\KlapOrderInterface;
use Improntus\Klap\Helper\Data as KlapHelper;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\MaskedQuoteIdToQuoteIdInterface;
use Improntus\Klap\Model\Rest\Connector;
use Improntus\Klap\Api\TransactionRepositoryInterface;
use Magento\Sales\Api\Data\TransactionInterface;
use Magento\Sales\Api\InvoiceManagementInterface;
use Magento\Sales\Api\OrderPaymentRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\Stdlib\DateTime;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\ResourceModel\Order\Collection as OrderCollection;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Sales\Api\InvoiceRepositoryInterface;
use Magento\Sales\Api\TransactionRepositoryInterface as PaymentTransactionRepository;

class KlapOrder implements KlapOrderInterface
{
    private const PAYMENT_METHODS = ['klap','klap_flex'];

    /**
     * @var MaskedQuoteIdToQuoteIdInterface
     */
    private $maskedQuoteIdToQuoteId;

    /**
     * @var Connector
     */
    private $connector;

    /**
     * @var TransactionRepositoryInterface
     */
    private $transactionRepository;

    /**
     * @var TransactionFactory
     */
    private $transactionFactory;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var DateTime
     */
    private $dateTime;

    /**
     * @var KlapHelper
     */
    private $helper;

    /**
     * @var Session
     */
    private Session $checkoutSession;

    /**
     * @var StoreManagerInterface
     */
    private StoreManagerInterface $storeManager;

    /**
     * @var OrderCollection
     */
    private OrderCollection $orderCollection;

    /**
     * @var InvoiceRepositoryInterface
     */
    private $invoiceRepository;

    /**
     * @var ResourceConnection
     */
    private $resourceConnection;

    /**
     * @var InvoiceManagementInterface
     */
    private $invoiceManagement;

    /**
     * @var OrderPaymentRepositoryInterface
     */
    private $paymentRepository;

    /**
     * @var OrderSender
     */
    private $orderSender;

    /**
     * @var PaymentTransactionRepository
     */
    private $paymentTransactionRepository;

    /**
     * @param MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId
     * @param TransactionRepositoryInterface $transactionRepository
     * @param TransactionFactory $transactionFactory
     * @param OrderRepositoryInterface $orderRepository
     * @param DateTime $dateTime
     * @param KlapHelper $helper
     * @param Session $session
     * @param StoreManagerInterface $storeManager
     * @param OrderCollection $orderCollection
     * @param InvoiceRepositoryInterface $invoiceRepository
     * @param ResourceConnection $resourceConnection
     * @param InvoiceManagementInterface $invoiceManagement
     * @param OrderPaymentRepositoryInterface $paymentRepository
     * @param OrderSender $orderSender
     * @param PaymentTransactionRepository $paymentTransactionRepository
     * @param Connector $connector
     */
    public function __construct(
        MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId,
        TransactionRepositoryInterface  $transactionRepository,
        TransactionFactory              $transactionFactory,
        OrderRepositoryInterface        $orderRepository,
        DateTime                        $dateTime,
        KlapHelper                      $helper,
        Session                         $session,
        StoreManagerInterface           $storeManager,
        OrderCollection                 $orderCollection,
        InvoiceRepositoryInterface      $invoiceRepository,
        ResourceConnection              $resourceConnection,
        InvoiceManagementInterface      $invoiceManagement,
        OrderPaymentRepositoryInterface $paymentRepository,
        OrderSender                     $orderSender,
        PaymentTransactionRepository    $paymentTransactionRepository,
        Connector                       $connector
    ) {
        $this->connector = $connector;
        $this->transactionRepository = $transactionRepository;
        $this->transactionFactory = $transactionFactory;
        $this->maskedQuoteIdToQuoteId = $maskedQuoteIdToQuoteId;
        $this->dateTime = $dateTime;
        $this->orderRepository = $orderRepository;
        $this->checkoutSession = $session;
        $this->storeManager = $storeManager;
        $this->orderCollection = $orderCollection;
        $this->invoiceRepository = $invoiceRepository;
        $this->invoiceManagement = $invoiceManagement;
        $this->resourceConnection = $resourceConnection;
        $this->paymentRepository = $paymentRepository;
        $this->orderSender = $orderSender;
        $this->paymentTransactionRepository = $paymentTransactionRepository;
        $this->helper = $helper;
    }

    /**
     * Create method
     *
     * @return array|mixed
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function create()
    {
        $quote = $this->checkoutSession->getQuote();
        if (!(int)($quote->getId())) {
            $this->maskedQuoteIdToQuoteId->execute($quote->getId());
        }
        $result = $this->connector->execute($this->storeManager->getStore()->getId(),
                    $quote->getPayment()->getMethod());
        return $result['order_id'] ?? $result;
    }

    /**
     * Creates klap_transaction entry
     *
     * @param $quote
     * @param $result
     * @param string $flow
     * @return Transaction | bool
     */
    public function persistTransaction($quote, $result, string $flow = 'response')
    {
        try {
            if ($flow !== 'response') {
                //At this point transaction ID is the order id from Klap
                $transactionId = $result['transaction_id'];
            } else {
                $transactionId = $result['id'];
            }
            $status = $result['status'] ?? '';
            $quoteId = $quote->getId();
            if(!$quoteId) {
                $quoteId = $result['quote_id'] ?? '';
            }
            $transaction = $this->transactionRepository->getByQuoteId($quoteId);
            //If the transaction exists, the webhook notification created the transaction first
            if (!$transaction || ($status === 'PENDING' && $transaction?->getStatus() !== "APPROVED")) {
                //This adds the pending status if the webhook did not fire for any reason
                $transaction = $transaction ?: $this->transactionFactory->create();
                $transaction->setOrderId($result['order_id'] ?? '');
                $transaction->setQuoteId($result['quote_id']);
                $transaction->setKlapTransactionId($transactionId ?? '');
                $transaction->setStatus($status);
                $transaction->setCreatedAt($this->dateTime->formatDate(true));
                $transaction->setIncrementId($result['increment_id'] ?? '');
                $transaction->setExpiredAt($result['expired_at'] ?? '');
                $this->transactionRepository->save($transaction);
            }
            return $transaction;
        } catch (Exception $e) {
            $this->helper->log(["message" => $e->getMessage(), "code" => $e->getCode()]);
            return false;
        }
    }

    /**
     * Handles order cancellation
     *
     * @param Order $order
     * @param string $message
     * @return bool
     */
    public function cancelOrder($order, $message)
    {
        try {
            if ($order->canCancel()) {
                $order->cancel();
                $order->setState(Order::STATE_CANCELED);
                $order->addCommentToStatusHistory($message, Order::STATE_CANCELED);
                $this->orderRepository->save($order);
                return true;
            }
        } catch (Exception $e) {
            $this->helper->log(["message" => $e->getMessage(), "code" => $e->getCode()]);
        }
        return false;
    }

    /**
     * Returns an order collection using a received status
     *
     * @param $status
     * @param string $alias
     * @return OrderCollection
     */
    public function getOrderCollection($status, $alias = "")
    {
        $this->orderCollection->getSelect()
            ->joinLeft(
                ["sop" . $alias => "sales_order_payment"],
                'main_table.entity_id = sop' . $alias . '.parent_id',
                ['method']
            )
            ->where('sop' . $alias . '.method IN (?)', [self::PAYMENT_METHODS]);
        $this->orderCollection->addFieldToFilter('status', $status);
        return $this->orderCollection;
    }

    /**
     * Process pending orders and updates klap transaction
     *
     * @param $order
     * @param $klapTransaction
     * @return bool
     */
    public function processPending($order, $klapTransaction)
    {
        $connection = $this->resourceConnection->getConnection();
        $connection->beginTransaction();
        try {
            $wsResponse = $this->connector->checkOrderByKlapId($klapTransaction->getKlapTransactionId(),
            $order?->getPayment()?->getMethod(), $order?->getStoreId());
            $webhookTransaction = $this->transactionRepository->getStatusByQuoteId($order?->getQuoteId());

            if (array_key_exists("code", $wsResponse) ||
                ($wsResponse["status"] !== "completed" && $webhookTransaction !== "APPROVED") ||
                ($wsResponse["status"] === "rejected")) {
                //APPROVED Webhooks will not be overridden by persisttransaction on order create
                //If the order id is pending on async calls, persisttransaction will override the rejected webhook
                //and cancel it on order cancel, while retaining the APPROVED webhooks
                $this->helper->log(["message" => "The Webservice response was not successful",
                    "data" => json_encode($wsResponse)]);
                $connection->rollBack();
                return false;
            }
            $invoice = $this->invoiceManagement->prepareInvoice($order);
            $invoice->register();
            $this->orderRepository->save($order);
            $transactionId = $klapTransaction->getTransactionId();
            $invoice->setTransactionId($transactionId);
            $payment = $order->getPayment();
            if(isset($wsResponse['payment_details'])) {
                $mapData = [
                    'order_id' => $wsResponse['order_id'] ?? '',
                    'method_title' => $payment->getAdditionalInformation()['method_title'] ?? 'Klap'
                ];
                foreach ($wsResponse['payment_details'] as $dataTuple) {
                    if (!isset($dataTuple['key'], $dataTuple['value'])) {
                        continue;
                    }
                    $mapData[$dataTuple['key']] = $dataTuple['value'];
                }
                $payment->setAdditionalInformation($mapData);
            }
            $this->paymentRepository->save($payment);
            $transaction = $this->generateTransaction($payment, $invoice, $transactionId);
            $transaction->setAdditionalInformation('amount', round($order->getGrandTotal(), 2));
            $transaction->setAdditionalInformation(
                'currency',
                $this->storeManager->getStore()->getCurrentCurrencyCode()
            );
            $this->paymentTransactionRepository->save($transaction);
            if (!$order->getEmailSent()) {
                $this->orderSender->send($order);
                $order->setIsCustomerNotified(true);
            }
            $invoice->pay();
            $invoice->getOrder()->setIsInProcess(true);
            $payment->addTransactionCommentsToOrder($transaction, __('Klap'));
            $this->invoiceRepository->save($invoice);
            $message = (__('Payment Approved in Klap'));
            $message .= __('| Klap Id: ') . $klapTransaction->getKlapTransactionId();
            $message .= ' | Klap Current Status: ' . $wsResponse["status"];
            if(array_key_exists('payment_details', $wsResponse)) {
                foreach ($wsResponse['payment_details'] as $paymentValue) {
                    if ($paymentValue['key'] == 'mc_code') {
                        $message .= ' | Klap MC Code: ' . $paymentValue['value'];
                        break;
                    }
                }
            }
            $order->addCommentToStatusHistory($message, Order::STATE_PROCESSING);
            $this->orderRepository->save($order);
            $klapTransaction->setStatus('PROCESSED');
            $klapTransaction->setExpiredAt(null);
            if (!$klapTransaction->getOrderId()) {
                //If the success notification reaches before the order generation, we update the ID
                $klapTransaction->setOrderId($order->getId());
                $klapTransaction->setIncrementId($order->getIncrementId());
            }
            $this->transactionRepository->save($klapTransaction);
            $connection->commit();
            return true;
        } catch (\Exception $e) {
            $connection->rollBack();
            $message = "Invoice creating for order {$order->getIncrementId()} failed: \n";
            $message .= $e->getMessage() . "\n";
            $logInfo = [
                "message" => $message,
                "transaction" => $klapTransaction->getKlapTransactionId(),
                "quote_id" => $klapTransaction->getQuoteId()
            ];
            $this->helper->log($logInfo);
            return false;
        }
    }

    /**
     * Adds klap_transaction entry
     *
     * @param $payment
     * @param $invoice
     * @param $transactionId
     * @return mixed
     */
    private function generateTransaction($payment, $invoice, $transactionId)
    {
        $payment->setTransactionId($transactionId);
        return $payment->addTransaction(TransactionInterface::TYPE_CAPTURE, $invoice, true);
    }

    /**
     * Changes klap_transaction status for transactions with order generated that expired
     *
     * @param $quoteId
     * @throws LocalizedException
     */
    public function updateExpiredTransaction($quoteId)
    {
        $transaction = $this->transactionRepository->getByQuoteId($quoteId);
        if ($transaction !== false) {
            $transaction->setStatus("CANCELED");
            $this->transactionRepository->save($transaction);
        }

    }
}
