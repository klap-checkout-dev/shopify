<?php

namespace Improntus\Klap\Model;

use Improntus\Klap\Api\Data\TransactionInterface;
use Improntus\Klap\Api\Data\TransactionInterfaceFactory;
use Improntus\Klap\Api\Data\TransactionSearchResultsInterfaceFactory;
use Improntus\Klap\Api\TransactionRepositoryInterface;
use Improntus\Klap\Model\ResourceModel\Transaction as ResourceTransaction;
use Improntus\Klap\Model\ResourceModel\Transaction\CollectionFactory as TransactionCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Stdlib\DateTime;

class TransactionRepository implements TransactionRepositoryInterface
{

    /**
     * @var ResourceTransaction
     */
    protected $resource;

    /**
     * @var TransactionInterfaceFactory
     */
    protected $transactionFactory;

    /**
     * @var TransactionCollectionFactory
     */
    protected $transactionCollectionFactory;

    /**
     * @var Transaction
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var DateTime
     */
    private $dateTime;

    /**
     * @param ResourceTransaction $resource
     * @param TransactionInterfaceFactory $transactionFactory
     * @param TransactionCollectionFactory $transactionCollectionFactory
     * @param TransactionSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param DateTime $dateTime
     */
    public function __construct(
        ResourceTransaction                      $resource,
        TransactionInterfaceFactory              $transactionFactory,
        TransactionCollectionFactory             $transactionCollectionFactory,
        TransactionSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface             $collectionProcessor,
        SearchCriteriaBuilder                    $searchCriteriaBuilder,
        DateTime                                 $dateTime
    ) {
        $this->resource = $resource;
        $this->transactionFactory = $transactionFactory;
        $this->transactionCollectionFactory = $transactionCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->dateTime = $dateTime;
    }

    /**
     * @inheritDoc
     */
    public function save(TransactionInterface $transaction)
    {
        try {
            $this->resource->save($transaction);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the transaction: %1',
                $exception->getMessage()
            ));
        }
        return $transaction;
    }

    /**
     * @inheritDoc
     */
    public function get($transactionId)
    {
        $transaction = $this->transactionFactory->create();
        $this->resource->load($transaction, $transactionId, TransactionInterface::KLAP_TRANSACTION_ID);
        if (!$transaction->getId()) {
            throw new NoSuchEntityException(__('Transaction with id "%1" does not exist.', $transactionId));
        }
        return $transaction;
    }

    public function getByOrderId($orderId)
    {
        $transaction = $this->transactionFactory->create();
        $this->resource->load($transaction, $orderId, 'order_id');
        if (!$transaction->getId()) {
            return false;
        }
        return $transaction;
    }

    /**
     * @inheritDoc
     */
    public function getByQuoteId($quoteId)
    {
        $transaction = $this->transactionFactory->create();
        $this->resource->load($transaction, $quoteId, 'quote_id');
        if (!$transaction->getId()) {
            return false;
        }
        return $transaction;
    }

    /**
     * @inheritDoc
     */
    public function getStatusByQuoteId($quoteId)
    {
        $transaction = $this->transactionFactory->create();
        $this->resource->load($transaction, $quoteId, 'quote_id');
        if (!$transaction->getId()) {
            return false;
        }
        return $transaction->getStatus();
    }

    /**
     * @inheritDoc
     */
    public function getByIncrementId($incrementId)
    {
        $transaction = $this->transactionFactory->create();
        $this->resource->load($transaction, $incrementId, 'increment_id');
        if (!$transaction->getId()) {
            return false;
        }
        return $transaction;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    ) {
        $collection = $this->transactionCollectionFactory->create();

        $this->collectionProcessor->process($searchCriteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(TransactionInterface $transaction)
    {
        try {
            $transactionModel = $this->transactionFactory->create();
            $this->resource->load($transactionModel, $transaction->getTransactionId());
            $this->resource->delete($transactionModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Transaction: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($transactionId)
    {
        return $this->delete($this->get($transactionId));
    }

    /**
     * Returns transactions with received status
     * @return \Improntus\Klap\Api\Data\TransactionInterface[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getTransactionCollection($status)
    {
        $criteria = $this->searchCriteriaBuilder
            ->addFilter('status', $status)
            ->create();
        return $this->getList($criteria)->getItems();
    }

    /**
     * Process transaction returned from Webhook Notification
     *
     * @throws LocalizedException
     */
    public function processNotificationTransaction($order, $transaction, $data, $originStatus)
    {
        if (!$transaction) {
            $transaction = $this->transactionFactory->create();
            $transaction->setIncrementId($order ? $order->getIncrementId() : '');
            $transaction->setCreatedAt($this->dateTime->formatDate(true));
            $transaction->setQuoteId($data->reference_id);
            $transaction->setOrderId($order ? $order->getId() : '0');
            $transaction->setExpiredAt($this->dateTime->formatDate(true));
            $data->order_id ? $transaction->setKlapTransactionId($data->order_id) :
                $transaction->setKlapTransactionId('');
            isset($data->status) ? $transaction->setStatus(strtoupper($data->status)) :
                $transaction->setStatus($originStatus);
        }
        if (strtoupper($transaction->getStatus()) !== 'APPROVED' && $originStatus == "APPROVED") {
            $data->approval_code ? $transaction->setStatus("APPROVED") :
                $transaction->setStatus("PENDING");
            $transaction->setExpiredAt(null);
            $transaction->setKlapTransactionId($data->order_id);
        }
        $this->save($transaction);
    }
}
