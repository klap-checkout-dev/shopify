<?php

namespace Improntus\Klap\Model;

use Magento\Framework\Model\AbstractModel;
use Improntus\Klap\Model\ResourceModel\KlapLogs as ResourceModel;

/**
 * KlapLogs Table Model
 */
class KlapLogs extends AbstractModel
{
    private const LOG_ID = 'entity_id';
    private const KLAP_TRANSACTION_ID = 'transaction_id';
    private const STATUS = 'status';
    private const RAW_RESPONSE = 'raw_response';
    private const CREATED_AT = 'created_at';

    /**
     * Constructor
     *
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * Retrieves table ID value
     *
     * @return int|string|null
     */
    public function getLogId()
    {
        return $this->getData(self::LOG_ID);
    }

    /**
     * Sets table ID value
     *
     * @param $logId
     * @return KlapLogs
     */
    public function setLogId($logId)
    {
        return $this->setData(self::LOG_ID, $logId);
    }

    /**
     * Gets Klap's order_id from logs
     *
     * inherit phpdoc
     */
    public function getKlapTransactionId()
    {
        return $this->getData(self::KLAP_TRANSACTION_ID);
    }

    /**
     * Sets Klap's order_id for logs
     *
     * inherit phpdoc
     */
    public function setKlapTransactionId($klapTransactionId)
    {
        return $this->setData(self::KLAP_TRANSACTION_ID, $klapTransactionId);
    }

    /**
     * Gets current log status
     *
     * inherit phpdoc
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * Sets current log status
     *
     * inherit phpdoc
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * Gets created_at data from row
     *
     * inherit phpdoc
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Sets created_at data for row
     *
     * inherit phpdoc
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Gets foreign key quote_id from transaction row
     *
     * inherit phpdoc
     */
    public function getRawResponse()
    {
        return $this->getData('raw_response');
    }

    /**
     * Sets foreign key quote_if for transaction row
     *
     * inherit phpdoc
     */
    public function setRawResponse($rawResponse)
    {
        return $this->setData(self::RAW_RESPONSE, $rawResponse);
    }
}
