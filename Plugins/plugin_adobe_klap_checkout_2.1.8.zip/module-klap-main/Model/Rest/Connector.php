<?php

namespace Improntus\Klap\Model\Rest;

use Exception;
use Magento\Framework\HTTP\Client\Curl;
use GuzzleHttp\ClientFactory;
use GuzzleHttp\Psr7\ResponseFactory;
use Improntus\Klap\Helper\Data;
use Magento\Checkout\Model\Session;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\Webapi\Rest\Request;

/**
 *
 */
class Connector
{
    /**
     * @var ResponseFactory
     */
    private $responseFactory;

    /**
     * @var ClientFactory
     */
    private $clientFactory;

    /**
     * @var Json
     */
    private $json;

    /**
     * @var Curl
     */
    protected Curl $curlClient;

    /**
     * @var Session
     */
    private Session $checkoutSession;

    /**
     * @var Data
     */
    private Data $helper;

    /**
     * @param ClientFactory $clientFactory
     * @param ResponseFactory $responseFactory
     * @param Json $json
     * @param Session $checkoutSession
     * @param Data $helper
     * @param Curl $curl
     */
    public function __construct(
        ClientFactory   $clientFactory,
        ResponseFactory $responseFactory,
        Json            $json,
        Session         $checkoutSession,
        Data            $helper,
        Curl            $curl
    ) {
        $this->json = $json;
        $this->clientFactory = $clientFactory;
        $this->responseFactory = $responseFactory;
        $this->checkoutSession = $checkoutSession;
        $this->helper = $helper;
        $this->curlClient = $curl;
    }

    /**
     * @param $storeId
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function execute($storeId, $paymentMethod): array
    {
        $payload = $this->generatePayload($paymentMethod);
        $payload = $this->json->serialize($payload);
        return $this->doRequest($payload,$paymentMethod, $storeId);
    }

    /**
     * @param $payload
     * @param $paymentMethod
     * @param $storeId
     * @param string $requestMethod
     * @return array|null
     */
    private function doRequest($payload, $paymentMethod, $storeId, string $requestMethod = Request::HTTP_METHOD_POST): ?array
    {
        $client = $this->clientFactory->create();
        $url = $this->helper->isSandbox($paymentMethod, $storeId) ? $this->helper->getSandboxApiUrl() :
            $this->helper->getProductionApiUrl();
        try {
            $this->curlClient->addHeader('Content-Type', 'application/json');
            $this->curlClient->addHeader('apikey', $this->helper->getApiToken($paymentMethod, $storeId));
            switch ($requestMethod) {
                case Request::HTTP_METHOD_GET:
                    $url = $url . $payload;
                    $this->curlClient->get($url);
                    break;
                case Request::HTTP_METHOD_POST:
                default:
                    $this->curlClient->addHeader('Content-Length', strlen($payload));
                    $this->curlClient->post($url, $payload);
                    break;
            }
        } catch (Exception $exception) {
            $this->helper->log(["response_klap_error" => $exception->getMessage()]);
            $response = $this->responseFactory->create([
                'status' => $exception->getCode(),
                'reason' => $exception->getMessage(),
            ]);
        }
        return json_decode($this->curlClient->getBody(), true) ;
    }

    /**
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    private function generatePayload($paymentMethod): array
    {
        $quote = $this->checkoutSession->getQuote();
        $quote->reserveOrderId();
        $shippingAddress = $quote->getShippingAddress();
        $items = $quote->getItems();
        $itemsData = [];
        $currency = $this->helper->getCurrency();
        /*foreach ($items as $item) {
            $itemsData[] = [
                "name" => $item->getName(),
                "code" => $item->getSku(),
                "price" => $this->formatValue($item->getPrice() * $item->getQty()),
                "unit_price" => $this->formatValue($item->getPrice()),
                "quantity" => $item->getQty(),
            ];
        }*/
        return [
            "reference_id" => $quote->getId(),
            "user" => [
                "email" => $shippingAddress->getEmail() ? $shippingAddress->getEmail() : null,
                "first_name" => $shippingAddress->getFirstname() ? $shippingAddress->getFirstname() : null,
                "last_name" => $shippingAddress->getLastname() ? $shippingAddress->getLastname() : null,
            ],
            "amount" => [
                "currency" => $currency,
                "total" => $this->formatValue($quote->getGrandTotal()),
                "details" => [
                    "subtotal" => $this->formatValue($quote->getSubtotal()),
                    "fee" => $this->formatValue($shippingAddress->getShippingAmount()),
                ],
            ],
            "methods" => [
                "tarjetas",
            ],
            //"items" => $itemsData,
            "customs" => $this->getCustoms(),
            "webhooks" => $this->helper->getWebhooks($paymentMethod)
        ];
    }

    /**
     * @param $string
     * @return float
     */
    private function formatValue($string): float
    {
        $string = str_replace(',', '.', $string);
        return floatval($string);
    }

    /**
     * @return array
     */
    private function getCustoms() {
        $customsArray =
        [
            [
                "key" => "tarjetas_expiration_minutes",
                "value" => $this->helper->getCardExpiration()
            ],
            [
                "key" => "notify_payment_user",
                "value" => "true",
            ]
        ];
        if($this->helper->willNotifyMerchant()) {
            $customsArray[] =
                [
                    "key" => "notify_payment_merchant",
                    "value" => "true"
                ];
            $customsArray[] =    [
                    "key" => "notify_payment_email_merchant",
                    "value" => $this->helper->willNotifyMerchant(),
                ];
        }
        return $customsArray;
    }

    /**
     * @param string $klapOrderId
     * @param null $paymentMethod
     * @param null $storeId
     * @return array
     */
    public function checkOrderByKlapId($klapOrderId, $paymentMethod = null, $storeId = null)
    {
        return $this->doRequest('/' . $klapOrderId,$paymentMethod, $storeId, Request::HTTP_METHOD_GET);
    }

}
