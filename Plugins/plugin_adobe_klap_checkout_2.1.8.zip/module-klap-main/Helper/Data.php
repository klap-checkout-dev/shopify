<?php
/**
 * Copyright © Improntus All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Improntus\Klap\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Improntus\Klap\Logger\Logger;
use Magento\Framework\Serialize\Serializer\Json;


use Safe\Exceptions\UrlException;

class Data extends AbstractHelper
{
    public const INCOMPLETE_CREDENTIALS = 0;
    public const USER_AUTHENTICATED = 1;
    public const LOGGER_NAME = 'klap';
    public const UPLOAD_DIR = 'klap/';
    public const STATUS_OK = [200, 201];
    public const STATUS_UNAUTHORIZED = [400, 401, 403];
    public const STATUS_CONFIRMATION = 'confirmation';
    public const STATUS_SUCCESS = 'success';
    public const STATUS_FINAL = 'final';
    public const STATUS_REJECTED = 'rejected';
    public const STATUS_ERROR = 'error';
    public const STATUS_CANCELED = 'canceled';
    public const STATUSES_SUCCESS = [self::STATUS_CONFIRMATION, self::STATUS_SUCCESS, self::STATUS_FINAL];
    public const STATUSES_CANCEL = [self::STATUS_REJECTED, self::STATUS_ERROR, self::STATUS_CANCELED];
    public const XML_PATH_IMPRONTUS_KLAP_PAYMENT_ACTIVE = 'payment/klap/active';
    public const XML_PATH_IMPRONTUS_KLAP_PAYMENT_SANDBOX = 'payment/klap/sandbox';
    public const XML_PATH_IMPRONTUS_KLAP_PAYMENT_TITLE = 'payment/klap/title';
    public const XML_PATH_IMPRONTUS_KLAP_PAYMENT_LOGO = 'payment/klap/logo';
    public const XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_ACTIVE = 'payment/klap_flex/active';
    public const XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_SANDBOX = 'payment/klap_flex/sandbox';
    public const XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_TITLE = 'payment/klap_flex/title';
    public const XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_API_TOKEN = 'payment/klap_flex/token';
    public const XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_LOGO = 'payment/klap_flex/logo';
    public const NOTIFY_MERCHANT = 'payment/klap_flex/notify_merchant';
    public const CARD_EXPIRATION = 'payment/klap_flex/card_expiration';
    public const COUNTRY_CODE_PATH = 'general/country/default';
    public const CONFIG_ROOT = 'payment/klap/';
    public const EP_MERCHANT_TRANSACTIONS = 'merchant-transactions';

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var Json
     */
    private $serializer;

    /**
     * Helper Constructor
     *
     * @param Context $context
     * @param EncryptorInterface $encryptor
     * @param Logger $logger
     * @param Json $serializer
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context               $context,
        Logger                $logger,
        Json                  $serializer,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->logger = $logger;
        $this->storeManager = $storeManager;
        $this->serializer = $serializer;
    }

    /**
     * Get Config Value method
     *
     * @param string $field
     * @param int|null $storeId
     * @return string|null
     */
    public function getConfigValue(string $field, int $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * Retrieve if payment method is enabled
     *
     * @return boolean
     */
    public function isEnabled($code)
    {   if($code === 'klap') {
            return (bool)$this->getConfigValue(self::XML_PATH_IMPRONTUS_KLAP_PAYMENT_ACTIVE);
        }
        else {
            return (bool)$this->getConfigValue(self::XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_ACTIVE);
        }
    }

    /**
     * Retrieve payment method title
     *
     * @return string
     */
    public function getTitle($code)
    {   if($code === 'klap') {
            return $this->getConfigValue(self::XML_PATH_IMPRONTUS_KLAP_PAYMENT_TITLE);
        }
        else {
            return $this->getConfigValue(self::XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_TITLE);
        }
    }

    /**
     * Retrieve API authorization token
     *
     * @return string
     */
    public function getApiToken($paymentMethod, $storeId = null)
    {
        return
            $this->getConfigValue(self::XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_API_TOKEN, $storeId) ?? '';
    }

    /**
     * Is Sandbox method
     *
     * @return bool
     */
    public function isSandbox($paymentMethod, $storeId = null)
    {
        return $paymentMethod === 'klap_flex' ?
        (bool)$this->getConfigValue(self::XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_SANDBOX, $storeId) :
            (bool)$this->getConfigValue(self::XML_PATH_IMPRONTUS_KLAP_PAYMENT_SANDBOX, $storeId);
    }

    /**
     * Get Config Webhooks
     *
     * @return array
     * @throws NoSuchEntityException
     */
    public function getWebhooks($paymentMethod)
    {
        if ($this->isSandbox($paymentMethod)) {
            $identifier = $paymentMethod === 'klap_flex' ? 'klap_flex':'klap';
            $validation = $this->getConfigValue('payment/'.$identifier.'/sandbox_validation_webhook');
            $error = $this->getConfigValue('payment/'.$identifier.'/sandbox_error_webhook');
            $success = $this->getConfigValue('payment/'.$identifier.'/sandbox_success_webhook');
        }

        return [
            "webhook_validation" => $validation ?? $this->getUrl('klap/notification/notification'),
            "webhook_confirm" => $success ?? $this->getUrl('klap/notification/successnotification'),
            "webhook_reject" => $error ?? $this->getUrl('klap/notification/failurenotification')
        ];
    }

    /**
     * Return logo img path
     *
     * @return string|null
     * @throws NoSuchEntityException
     */
    public function getLogo($code)
    {
        $configPath = $code === 'klap_flex' ? self::XML_PATH_IMPRONTUS_KLAP_FLEX_PAYMENT_LOGO :
            self::XML_PATH_IMPRONTUS_KLAP_PAYMENT_LOGO;
        if ($filePath = $this->getConfigValue($configPath)) {
            return $this->storeManager->getStore()
                    ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA) . self::UPLOAD_DIR . $filePath;
        }
        return $filePath;
    }

    /**
     * Validate credentials
     *
     * @return integer
     */
    public function validateCredentials($code)
    {
        if ($this->getApiToken($code)) {
            return self::USER_AUTHENTICATED;
        }
        return self::INCOMPLETE_CREDENTIALS;
    }

    /**
     * Get Sandbox API Url
     *
     * @return string
     */
    public function getSandboxApiUrl()
    {
        //sandbox para klap
        return 'https://api-pasarela-sandbox.mcdesaqa.cl/payment-gateway/v1/orders';
        //sandbox para flex
        //return 'https://api-pasarela-verticalqa.mcdesaqa.cl/payment-gateway/v1/orders';
    }

    /**
     * Get Production API Url
     *
     * @return string
     */
    public function getProductionApiUrl()
    {
        return 'https://api.pasarela.multicaja.cl/payment-gateway/v1/orders';
    }

    /**
     * Log method
     *
     * @param array $data
     * @return void
     */
    public function log(array $data)
    {
        $this->logger->debug($this->serializer->serialize($data));
    }

    /**
     * Get Script Url method
     *
     * @return string
     */
    public function getScriptUrl()
    {
        if ($this->isSandbox('klap')) {
            return 'https://pagos-pasarela-sandbox.mcdesaqa.cl/checkout-frictionless/v1/main.min.js';
        } else {
            return 'https://pagos.pasarela.multicaja.cl/checkout-frictionless/v1/main.min.js';
        }
    }

    /**
     * Get Flex Script Url method
     *
     * @return string
     */
    public function getFlexScriptUrl()
    {
        if ($this->isSandbox('klap_flex')) {
            //return 'https://verticalqa.mcdesaqa.cl/pagos/checkout-flex/v1/main.min.js';
            return 'https://sandbox.mcdesaqa.cl/pagos/checkout-flex/v1/main.min.js';
        } else {
            return 'https://www.klap.cl/pagos/checkout-flex/v1/main.min.js';
        }
    }

    /**
     * Retrieve store currency code
     *
     * @param int|string|null $storeId
     * @return string
     * @throws NoSuchEntityException
     * @throws LocalizedException
     */
    public function getCurrency(int|string $storeId = null)
    {
        return $this->storeManager->getStore($storeId)->getCurrentCurrency()->getCode();
    }

    /**
     * Get Url method
     *
     * @param string $path
     * @param array|null $params
     * @return string
     * @throws NoSuchEntityException
     */
    public function getUrl(string $path, ?array $params = null)
    {
        if ($params) {
            return $this->storeManager->getStore()->getUrl($path, $params);
        }
        return $this->storeManager->getStore()->getUrl($path);
    }

    /**
     * Get Redirect Url method
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getRedirectUrl()
    {
        return $this->getUrl('klap/order/create');
    }

    /**
     * Get Failure Url method
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getFailUrl()
    {
        return $this->getUrl('checkout/onepage/failure/');
    }

    /**
     * Get Origin Url method
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getOriginUrl()
    {
        return rtrim($this->getUrl(''), '/');
    }

    /**
     * Get Cancel Hours method
     *
     * @param mixed $storeId
     * @return mixed|string
     */
    public function getCancelHours(mixed $storeId = null)
    {
        return $this->getConfigData('cancel_hours', $storeId) ?? '';
    }

    /**
     * Get Config Data method
     *
     * @param string $value
     * @param mixed|null $storeId
     * @return mixed
     */
    public function getConfigData(string $value, mixed $storeId = null)
    {
        $path = $this::CONFIG_ROOT . $value;
        return $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeId) ?? '';
    }

    /**
     * @return bool|string
     */
    public function willNotifyMerchant()
    {
        return $this->scopeConfig->getValue($this::NOTIFY_MERCHANT);
    }

    /**
     * @return string
     */
    public function getCardExpiration()
    {
        return $this->scopeConfig->getValue($this::CARD_EXPIRATION) ?
            $this->scopeConfig->getValue($this::CARD_EXPIRATION) : '30';
    }

    /**
     * Validates header api key for webhook endpoints
     * @param $referenceId
     * @param $orderId
     * @param $headerApiKey
     * @return bool
     */
    public function validateWebhook($referenceId, $orderId, $headerApiKey) {
        return hash('sha256', $referenceId . $orderId .  $this->getApiToken('klap_flex')) ===
           $headerApiKey;

    }
}
