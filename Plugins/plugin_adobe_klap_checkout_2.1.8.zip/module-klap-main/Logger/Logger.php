<?php
/**
 * Copyright © Improntus All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Improntus\Klap\Logger;

/**
 * Class Logger
 */
class Logger extends \Monolog\Logger
{
    /**
     * Set Name
     *
     * @param $name
     * @return void
     */
    public function setName($name)
    {
        $this->name = $name;
    }
}
