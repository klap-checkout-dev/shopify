<?php

namespace Improntus\Klap\Api;

interface TransactionRepositoryInterface
{

    /**
     * Save Transaction
     * @param \Improntus\Klap\Api\Data\TransactionInterface $transaction
     * @return \Improntus\Klap\Api\Data\TransactionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Improntus\Klap\Api\Data\TransactionInterface $transaction
    );

    /**
     * Retrieve Transaction
     * @param string $transactionId
     * @return \Improntus\Klap\Api\Data\TransactionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($transactionId);

    /**
     * Retrieve Transaction
     * @param int $orderId
     * @return \Improntus\Klap\Api\Data\TransactionInterface | false
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getByOrderId($orderId);

    /**
     * Retrieve Transaction by Quote
     * @param int $quoteId
     * @return \Improntus\Klap\Api\Data\TransactionInterface | false
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getByQuoteId($quoteId);

    /**
     * Retrieve Status by Quote
     * @param int $quoteId
     * @return string | false
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getStatusByQuoteId($quoteId);

    /**
     * Retrieve Transaction by Increment
     * @param string $incrementId
     * @return \Improntus\Klap\Api\Data\TransactionInterface | false
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getByIncrementId($incrementId);

    /**
     * Retrieve Transaction matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Improntus\Klap\Api\Data\TransactionSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Transaction
     * @param \Improntus\Klap\Api\Data\TransactionInterface $transaction
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Improntus\Klap\Api\Data\TransactionInterface $transaction
    );

    /**
     * Delete Transaction by ID
     * @param string $transactionId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($transactionId);
}
