<?php

namespace Improntus\Klap\Api;

use Magento\Framework\Webapi\Exception;

interface KlapOrderInterface
{
    /**
     * @return mixed
     */
    public function create();
}
