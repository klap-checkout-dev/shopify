<?php

namespace Improntus\Klap\Api\Data;

interface TransactionSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Klap Transaction list.
     * @return \Improntus\Klap\Api\Data\TransactionInterface[]
     */
    public function getItems();

    /**
     * Set Klap Transaction list.
     * @param \Improntus\Klap\Api\Data\TransactionInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
