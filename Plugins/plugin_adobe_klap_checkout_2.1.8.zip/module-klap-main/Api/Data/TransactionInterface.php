<?php

namespace Improntus\Klap\Api\Data;

interface TransactionInterface
{
    public const TRANSACTION_ID = 'entity_id';
    public const ORDER_ID = 'order_id';
    public const QUOTE_ID = 'quote_id';
    public const KLAP_INCREMENT_ID = 'increment_id';
    public const KLAP_TRANSACTION_ID = 'transaction_id';
    public const STATUS = 'status';
    public const CREATED_AT = 'created_at';
    public const EXPIRED_AT = 'expired_at';

    /**
     * Get transaction_id
     * @return string|null
     */
    public function getTransactionId();

    /**
     * Set transaction_id
     * @param string $transactionId
     * @return \Improntus\Klap\Api\Data\TransactionInterface
     */
    public function setTransactionId($transactionId);

    /**
     * @return int|string|null
     */
    public function getOrderId();

    /**
     * @param $orderId
     * @return mixed
     */
    public function setOrderId($orderId);

    /**
     * @return string
     */
    public function getKlapTransactionId();

    /**
     * @param $klapTransactionId
     * @return mixed
     */
    public function setKlapTransactionId($klapTransactionId);

    /**
     * @return string
     */
    public function getStatus();

    /**
     * @param $status
     * @return mixed
     */
    public function setStatus($status);

    /**
     * @return mixed
     */
    public function getCreatedAt();

    /**
     * @param $createdAt
     * @return mixed
     */
    public function setCreatedAt($createdAt);

    /**
     * @return mixed
     */
    public function getExpiredAt();

    /**
     * @param $expiredAt
     * @return mixed
     */
    public function setExpiredAt($expiredAt);

    /**
     * @return int|string|null
     */
    public function getQuoteId();

    /**
     * @param $quoteId
     * @return mixed
     */
    public function setQuoteId($quoteId);

    /**
     * @return string|null
     */
    public function getIncrementId();

    /**
     * @param $incrementId
     * @return mixed
     */
    public function setIncrementId($incrementId);
}
