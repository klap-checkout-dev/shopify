<?php

namespace Improntus\Klap\Controller\Order;

use Exception;
use Improntus\Klap\Helper\Data;
use Improntus\Klap\Model\KlapOrder;
use Magento\Framework\UrlInterface;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order as SaleOrder;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LogLevel;

/**
 * Handles creation of klap_transaction on place order action
 */
class Create implements ActionInterface
{
    /**
     * @var Data
     */
    private $helper;
    /**
     * @var RedirectFactory
     */
    private $redirectFactory;

    /**
     * @var Session
     */
    private $session;

    /**
     * @var KlapOrder
     */
    private $klapOrder;

    /**
     * @var SaleOrder
     */
    private $order;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var UrlInterface
     */
    private $urlInterface;

    /**
     * @param Session $session
     * @param KlapOrder $klapOrder
     * @param RedirectFactory $redirectFactory
     * @param SaleOrder $order
     * @param StoreManagerInterface $storeManager
     * @param UrlInterface $urlInterface
     * @param Data $helper
     */
    public function __construct(
        Session               $session,
        KlapOrder             $klapOrder,
        RedirectFactory       $redirectFactory,
        SaleOrder             $order,
        StoreManagerInterface $storeManager,
        UrlInterface          $urlInterface,
        Data                  $helper
    ) {
        $this->helper = $helper;
        $this->redirectFactory = $redirectFactory;
        $this->klapOrder = $klapOrder;
        $this->order = $order;
        $this->storeManager = $storeManager;
        $this->session = $session;
        $this->urlInterface = $urlInterface;
    }

    /**
     * Execute function generates klap transaction and returns the onepage action
     *
     * @throws LocalizedException
     */
    public function execute()
    {
        $quote = $this->session->getQuote();
        $quote->reserveOrderId();
        $order = $this->order->loadByIncrementId($this->session->getLastRealOrder()->getIncrementId());
        $response = $order->getPayment()->getAdditionalInformation();
        $resultRedirect = $this->redirectFactory->create();
        if ($response) {
            if (!array_key_exists('order_id', $response)) {
                try {
                    $error_message = array_key_exists('message', $response) ?
                        $response['message'] :
                        'There was an error creating the order';
                    $this->helper->log(["message" => $error_message, "route" => 'order/create']);
                } catch (Exception $e) {
                    $this->helper->log(["message" => $e->getMessage(), "code" => $e->getCode()]);
                }
                $resultRedirect->setUrl($this->urlInterface->getUrl('klap/onepage/failure/'));
            } else {
                $transaction = [
                    "quote_id" => $this->session->getLastQuoteId(),
                    "status" => "PENDING",
                    "transaction_id" => $response['order_id'],
                    "increment_id" => $order->getIncrementId(),
                    "order_id" => $order->getId()
                ];
                $this->helper->log(["message" => "Order Created", "transaction" => $transaction]);
                $createdTransaction = $this->klapOrder->persistTransaction($quote, $transaction, 'create');
                try {
                    $processIntent = $this->klapOrder->processPending($order, $createdTransaction);
                    if ($processIntent === true) {
                        $resultRedirect->setUrl($this->urlInterface->getUrl('checkout/onepage/success/'));
                    } else {
                        if (is_array($processIntent) && $processIntent["status"] == "pending") {
                            $resultRedirect->setUrl($this->urlInterface->getUrl('klap/onepage/pending/'));
                        } else {
                            $this->klapOrder->cancelOrder($order, "Order was rejected when creating invoice");
                            $this->helper->log(["message" => "Invoice was not processed.", "transaction" => $transaction]);
                            $this->klapOrder->updateExpiredTransaction($this->session->getLastQuoteId());
                            $this->session->restoreQuote();
                            $resultRedirect->setUrl($this->urlInterface->getUrl('klap/onepage/failure/'), ['_secure' => true]);
                        }
                    }
                } catch (\Exception $e) {
                    $resultRedirect->setUrl($this->urlInterface->getUrl('klap/onepage/pending/'));
                }
            }
        } else {
            $this->helper->log(["message" =>
            "Order Fail", "order" =>
            $this->session->getLastRealOrder()->getIncrementId()]);
            $resultRedirect->setUrl($this->urlInterface->getUrl('klap/onepage/failure/'));
        }
        return $resultRedirect;
    }
}
