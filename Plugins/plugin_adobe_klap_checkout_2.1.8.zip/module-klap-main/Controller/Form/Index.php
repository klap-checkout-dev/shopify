<?php

namespace Improntus\Klap\Controller\Form;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Improntus\Klap\ViewModel\Result\Page;
use Improntus\Klap\ViewModel\Result\PageFactory;

/**
 * Executes the page render for payment form
 */
class Index extends Action
{
    /**
     * @var PageFactory
     */
    protected $pageFactory;

    /**
     * @param Context $context
     * @param PageFactory $pageFactory
     */
    public function __construct(
        Context     $context,
        PageFactory $pageFactory
    ) {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
    }

    /**
     * Execute function to return the page
     *
     * @return Page
     */
    public function execute()
    {
        $pageResult = $this->pageFactory->create();
        $pageResult->initLayout();
        return $pageResult;
    }
}
