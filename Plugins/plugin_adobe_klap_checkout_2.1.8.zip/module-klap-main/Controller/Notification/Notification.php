<?php

namespace Improntus\Klap\Controller\Notification;

use Improntus\Klap\Helper\Data as KlapHelper;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Webapi\Exception;
use Magento\Framework\Webapi\Rest\Response;
use Magento\Framework\Controller\Result\JsonFactory;
use Psr\Log\LogLevel;

/**
 * Handles Availability Webhook Notification
 */
class Notification implements HttpPostActionInterface
{
    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var KlapHelper
     */
    protected $klapHelper;

    /**
     * @var Response
     */
    protected $response;

    /**
     * @var JsonFactory
     */
    private $jsonFactory;

    /**
     * @param RequestInterface $request
     * @param KlapHelper $klapHelper
     * @param Response $response
     * @param JsonFactory $jsonFactory
     */
    public function __construct(
        RequestInterface $request,
        KlapHelper       $klapHelper,
        Response         $response,
        JsonFactory      $jsonFactory
    ) {
        $this->request = $request;
        $this->klapHelper = $klapHelper;
        $this->response = $response;
        $this->jsonFactory = $jsonFactory;
    }

    /**
     * Execute function
     */
    public function execute()
    {
        try {
            $data = ['result' => 'success', 'message' => 'POST request handled successfully'];
            $resultJson = $this->jsonFactory->create();
            return $resultJson->setData($data);
        } catch (\Exception $exception) {
            $this->klapHelper->log(["message" => $exception->getMessage(), "code" => $exception->getCode()]);
            throw new Exception(
                __('There was an error processing the notification.'),
                0,
                Exception::HTTP_INTERNAL_ERROR
            );
        }
    }
}
