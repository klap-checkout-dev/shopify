# Klap Payment Module

[![N|Solid](https://www.klap.cl/image/layout_set_logo?img_id=293212&t=1713895787894)](https://www.klap.cl/)

## Description
Klap module for Adobe Commerce and Magento Open Source.

### Installation
```sh
$ composer require improntus/module-klap
$ php bin/magento module:enable Improntus_Klap --clear-static-content
$ php bin/magento setup:upgrade
$ php bin/magento setup:static-content:deploy
```

### Configuration
You can configure the integration at:

1) Stores > Configuration > Payment methods > Klap

2) Stores > Configuration > Payment methods > Klap Flex

## Author

[![N|Solid](https://improntus.com/wp-content/uploads/2022/05/Logo-Site.png)](https://www.improntus.com)
