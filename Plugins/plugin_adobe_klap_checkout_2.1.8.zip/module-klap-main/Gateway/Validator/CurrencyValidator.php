<?php
/**
 * Copyright © Improntus All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Improntus\Klap\Gateway\Validator;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Payment\Gateway\Validator\ResultInterface;
use Magento\Payment\Gateway\Validator\ResultInterfaceFactory;
use Magento\Payment\Gateway\Validator\AbstractValidator;
use Improntus\Klap\Helper\Data as KlapHelper;
use Magento\Checkout\Model\Session;

/**
 * Currency Validator Class
 */
class CurrencyValidator extends AbstractValidator
{
    private const ALLOWEDCURRENCIES = ['CLP'];
    /**
     * @var KlapHelper
     */
    private KlapHelper $klapHelper;

    /**
     * @var Session
     */
    private Session $session;

    /**
     * Constructor
     *
     * @param ResultInterfaceFactory $resultInterfaceFactory
     * @param KlapHelper $klapHelper
     */
    public function __construct(
        ResultInterfaceFactory $resultInterfaceFactory,
        KlapHelper             $klapHelper,
        Session                $session
    ) {
        parent::__construct($resultInterfaceFactory);
        $this->klapHelper = $klapHelper;
        $this->session = $session;
    }

    /**
     * Validates the store currency matches Klap currency
     *
     * @param array $validationSubject
     * @return ResultInterface
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function validate(array $validationSubject)
    {
        $isValid = true;
        $fails = [];
        $maximumPurchaseValue = 50;
        if ($validationSubject['currency'] != $this->klapHelper->getCurrency($validationSubject['storeId'])
            || !in_array(strtoupper($validationSubject['currency']), self::ALLOWEDCURRENCIES)) {
            $isValid = false;
            $fails[] = __('Currency doesn\'t match.');
        }
        if ($this->session->getQuote()?->getGrandTotal() < $maximumPurchaseValue) {
            $isValid = false;
            $fails[] = __('Minimum price does not exceeds 50CLP.');
        }
        if(strlen($this->session->getQuote()->getShippingAddress()->getFirstname() ?: "") <= 1 ||
            strlen($this->session->getQuote()->getShippingAddress()->getLastname() ?: "") <= 1) {
            $isValid = false;
            $fails[] = __('Selected Shipping Address is not valid.');
        }
        return $this->createResult($isValid, $fails);
    }
}
