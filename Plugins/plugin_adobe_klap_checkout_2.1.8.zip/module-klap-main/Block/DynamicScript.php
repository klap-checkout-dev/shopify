<?php

namespace Improntus\Klap\Block;

use Improntus\Klap\Helper\Data;
use Magento\Framework\View\Element\Js\Components;
use Magento\Framework\View\Element\Template\Context;

/**
 * Returns URL for SDK to load on checkout page
 */
class DynamicScript extends Components
{
    /**
     * @var Data
     */
    protected $configHelper;

    /**
     * @param Context $context
     * @param Data $configHelper
     * @param array $data
     */
    public function __construct(Context $context, Data $configHelper, array $data = [])
    {
        $this->configHelper = $configHelper;
        parent::__construct($context, $data);
    }

    /**
     * Returns SDK URL from configuration
     * @return string
     */
    public function getScriptUrl()
    {
        return $this->configHelper->getScriptUrl();
    }

    /**
     * Returns Klap Flex Script
     * @return string
     */
    public function getFlexScriptUrl()
    {
        return $this->configHelper->getFlexScriptUrl();
    }
}
