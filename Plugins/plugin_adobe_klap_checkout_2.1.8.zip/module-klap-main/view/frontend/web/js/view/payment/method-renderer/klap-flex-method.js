define([
  'Magento_Checkout/js/view/payment/default',
  'jquery',
  'ko',
  'Improntus_Klap/js/lib/flex-api',
  'Magento_Checkout/js/action/place-order',
  'Magento_Checkout/js/model/full-screen-loader',
  'Magento_Checkout/js/model/quote',
  'Magento_CheckoutAgreements/js/model/agreement-validator',
  'Magento_Ui/js/model/messageList',
  'Magento_Ui/js/lib/view/utils/dom-observer',
  'mage/translate',
  'jquery/ui',
  'domReady!',
], function (
  Component,
  $,
  ko,
  flexApi,
  placeOrderAction,
  fullScreenLoader,
  quote,
  agreementValidators,
  messageList,
  domObserver,
  $t
) {
  'use strict';
  const CODE = 'klap_flex';
  const CONFIG_PAYMENT = window.checkoutConfig.payment[CODE];

  return Component.extend({
    defaults: {
      template: 'Improntus_Klap/payment/klap-flex',
    },
    orderIdApi: '/rest/V1/klap/order/',
    actionClose: 'remove-close-modal-button',
    klapContainer: "[data-role='klap-flex']",
    klapModal: '#klapModal',
    activePayment: ko.observable(false),
    isSandbox: CONFIG_PAYMENT?.is_sandbox,
    trustedOrigin: new URL(CONFIG_PAYMENT?.flex_script),
    dataOrderValidate: [
      'page-success-web',
      'page-success-mobile',
      'page-reject-web',
      'page-reject-mobile',
    ],
    dataPlaceOrder: ['page-process-payment-web', 'page-process-payment-mobile'],
    actionCloseModal: 'remove-close-modal-button',
    actionPayment: 'payment',
    isLoading: ko.observable(false),

    initialize: function () {
      this._super();
      flexApi();
      this.preventReload();
      return this;
    },

    /**
     *
     * @returns {String}
     */
    getCode: function () {
      return CODE;
    },

    /**
     *
     * @returns {String}
     */
    getTitle: function () {
      return 'KlapFlex';
    },

    /**
     * @returns {String}
     */
    getLogo: function () {
      return CONFIG_PAYMENT.logo;
    },

    /**
     *
     * @param {*} method
     * @returns {String}
     */
    getMethodLogo: function (method) {
      return CONFIG_PAYMENT.methods_img_url[method].img;
    },

    /**
     * Place order
     *
     * @param {*} data
     * @param {*} event
     * @returns {Void}
     */
    placeOrder: function (data, event) {
      const self = this;

      if (event) {
        event.preventDefault();
      }

      if (self.isPlaceOrderActionAllowed() === false) {
        return false;
      }

      self.isPlaceOrderActionAllowed(false);
      self
        .getPlaceOrderDeferredObject()
        .fail(function () {
          self.isPlaceOrderActionAllowed(true);
        })
        .always(function () {
          fullScreenLoader.stopLoader();
          self.isPlaceOrderActionAllowed(true);
        });

      return true;
    },

    /**
     * @return {*}
     */
    getPlaceOrderDeferredObject: function () {
      let self = this;
      return $.when(placeOrderAction(self.getData(), this.messageContainer));
    },

    /**
     * Get payment method data
     */
    getData: function () {
      return {
        method: this.item.method,
        additional_data: {
          order_id: window.sessionStorage.klapFlexOrderId,
        },
      };
    },

    /**
     * @returns {Void}
     */
    handleClick: async function (element, event) {
      const self = element;
      if (event) {
        event.preventDefault();
      }

      if (
        agreementValidators.validate(false) &&
        (quote.billingAddress._latestValue.firstname.length > 1 ||
          quote.billingAddress._latestValue.lastname.length > 1)
      ) {
        try {
          this.isLoading(true);
          const klapOrderId = await self.getKlapOrderId();
          if (typeof window?.KLAP_FLEX === 'object' && klapOrderId) {
            window.KLAP_FLEX.init({
              orderId: klapOrderId,
              useModal: true,
              debug: false,
            });

            self.activePayment(true);
            window.sessionStorage.klapFlexOrderId = klapOrderId;
          } else {
            console.error('Klap SDK no está cargado correctamente');
          }
        } catch (error) {
          console.error('Error al obtener el Klap Order ID:', error);
        } finally {
          this.isLoading(false);
        }
      } else {
        messageList.addErrorMessage({
          message: $t('Please verify billing data.'),
        });
      }
    },

    /**
     * @returns {Void}
     */
    handleIframeEvents: function () {
      const self = this;

      domObserver.get(this.klapModal, (element) => {
        const $buttonClose = $(element).find('button');
        $buttonClose.on('click', () => {
          this.activePayment(false);
        });

        window.addEventListener('message', (event) => {
          if (event.origin !== self.trustedOrigin.origin) {
            return;
          }

          if (event !== undefined) {
            try {
              const data =
                typeof event.data === 'string'
                  ? JSON.parse(event.data)
                  : event.data;
              const { action } = data,
                paymentStatus = data?.data ?? '';
              self.processPayment(action, paymentStatus);
            } catch (e) {
              if (!event.data?.command) {
                console.error('Error parsing message data:', e);
              }
            }
          }
        });
      });
    },

    /**
     *
     * @param {String|null} action
     * @param {*} paymentStatus
     */
    processPayment: function (action, paymentStatus) {
      if (this.dataPlaceOrder.includes(paymentStatus)) {
        this.placeOrder();
      }

      if (this.dataOrderValidate.includes(paymentStatus)) {
        this.activePayment(false);
      }

      if (action === this.actionPayment) {
        fullScreenLoader.startLoader();
        this.activePayment(false);
        window.location.href = CONFIG_PAYMENT?.redirect_url;
      }
    },

    /**
     *
     * @returns {Promise}
     */
    getKlapOrderId: function () {
      const self = this;
      return new Promise(function (resolve, reject) {
        $.ajax({
          url: self.orderIdApi,
          type: 'GET',
          dataType: 'json',
          showLoader: true,
          success: function (orderId) {
            typeof orderId === 'string'
              ? resolve(orderId)
              : reject('Error: Response no es un string');
          },
          error: function (error) {
            console.error(error);
            reject('Error en la solicitud AJAX');
          },
        }).always(function (response) {});
      });
    },

    /**
     * @returns {Void}
     */
    preventReload: function () {
      const beforeUnloadHandler = (e) => {
        e.preventDefault();
        e.returnValue = '';
      };

      quote.paymentMethod.subscribe((newValue) => {
        if (newValue !== CODE) {
          window.removeEventListener('beforeunload', beforeUnloadHandler);
        }
      });

      this.activePayment.subscribe((newValue) => {
        if (newValue) {
          window.addEventListener('beforeunload', beforeUnloadHandler);
        } else {
          window.removeEventListener('beforeunload', beforeUnloadHandler);
        }
      });
    },
  });
});
