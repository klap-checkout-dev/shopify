define([
    'jquery',
    'ko',
    'mage/translate',
    'Improntus_Klap/js/lib/jquery.card',
], function ($, ko, $t) {
    return {
        cardForm: null,
        init: function () {
            this.initGraphicCard();
            return this;
        },

        initGraphicCard: function () {
            $('#checkout-klap').card({
                container: '.klap-graphic-card',
                formSelectors: {
                    numberInput: 'input#cardNumber',
                    expiryInput: 'input#expiryDate',
                    cvcInput: 'input#cvv',
                    nameInput: 'input#klap-cardholder',
                },
                formatting: true,
                placeholders: {
                    number: '•••• •••• •••• ••••',
                    name: $t('Full Name'),
                    expiry: '••/••',
                    cvc: '•••'
                },
            });
        },
    };
})
