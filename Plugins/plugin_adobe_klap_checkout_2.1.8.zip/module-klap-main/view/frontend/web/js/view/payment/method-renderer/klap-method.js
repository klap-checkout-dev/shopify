/*
 * Copyright © Improntus All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'Magento_Checkout/js/view/payment/default',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Checkout/js/action/place-order',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_CheckoutAgreements/js/model/agreement-validator',
    'mage/translate',
    'jquery',
    'ko',
    'Magento_Checkout/js/model/url-builder',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Checkout/js/checkout-data'
], function (
    Component,
    quote,
    additionalValidators,
    placeOrderAction,
    fullScreenLoader,
    agreementValidators,
    $t,
    $,
    ko,
    urlBuilder,
    errorProcessor,
    selectPaymentMethodAction,
    checkoutData
) {
    'use strict';

    const CODE = 'klap'
    const CONFIG_PAYMENT = window.checkoutConfig.payment[CODE]

    return Component.extend({
        defaults: {
            template: 'Improntus_Klap/payment/klap',
            code: 'klap',
            cardType: ko.observable(''),
            quotas: ko.observable(''),
            orderId: ko.observable(null),
            creditCardHandler: null,
            currentMethod: ko.observable('')
        },
        initialize: function () {
            this._super();
            window.error = this.failure;
            window.success = this.success;
            this.initQuoteListener();
            this.initCurrentMethodListener();
            fullScreenLoader.startLoader();
            let orderInitiated = false;
            let waitingRedirect = false;
            let cardinalIframe = false;
            /**
             * This is to adjust the height of the iframe with the content so there is no scroll,
             * Controls errors for spinner and fatal redirects
             */
            setInterval(function () {
                let iframe = document.getElementById("klap-iframe");
                if (iframe.contentWindow.document.getElementById("Cardinal-CCA-IFrame") && !cardinalIframe) {
                    fullScreenLoader.stopLoader();
                    cardinalIframe = true;
                }
                if (iframe.contentWindow.document.body) {
                    iframe.height = iframe.contentWindow.document.body.scrollHeight;
                }
                if (iframe.contentWindow.formInitiated && !orderInitiated) {
                    iframe.contentWindow.createKlapOrder();
                    orderInitiated = true;
                }
                if (iframe.contentWindow.klapErrorResult) {
                    fullScreenLoader.stopLoader();
                    iframe.contentWindow.klapErrorResult = false;
                    //orderInitiated = false;
                }
                if (iframe.contentWindow.redirectError && !waitingRedirect) {
                    fullScreenLoader.startLoader();
                    window.location.href = window.checkoutConfig.payment['klap'].error_url;
                    waitingRedirect = true;
                }
            }, 500);

            quote.totals.subscribe(function (data) {
                let iframe = document.getElementById("klap-iframe");
                if (iframe.contentWindow.formInitiated) {
                    iframe.contentWindow.createKlapOrder();
                }
            });
            return this;
        },

        getIframeUrl: function () {
            return `/klap/form/index/`;
        },

        placeOrder: function (data, event) {
            if (!agreementValidators.validate(false)) return;
            fullScreenLoader.startLoader();
            let self = this;
            let response = false;
            let iframe = document.getElementById("klap-iframe");
            iframe.contentWindow.klapErrorResult = false;
            iframe.contentWindow.executePay();
            window.addEventListener('message', function (event) {
                if (event.data) {
                    if (event) {
                        event.preventDefault();
                    }
                    window.sessionStorage.klapOrderId = event.data.orderId;
                    if (event.origin !== window.checkoutConfig.payment['klap'].origin_url) {
                        fullScreenLoader.stopLoader();
                        return;
                    }
                    self.isPlaceOrderActionAllowed(false);
                    self.getPlaceOrderDeferredObject()
                        .fail(function () {
                            fullScreenLoader.stopLoader();
                            self.isPlaceOrderActionAllowed(true);
                        })
                        .done(function () {
                            if (iframe.contentWindow.klapErrorResult) {
                                fullScreenLoader.stopLoader();
                                window.location.href = window.checkoutConfig.payment['klap'].error_url;
                                return false;
                            }
                            self.afterPlaceOrder();
                        })
                        .always(function () {
                            fullScreenLoader.stopLoader();
                            self.isPlaceOrderActionAllowed(true);
                        });
                }
            });

        },

        afterPlaceOrder: function () {
            fullScreenLoader.startLoader();
            window.location.href = window.checkoutConfig.payment['klap'].redirect_url;
        },

        setDocumentNumber: function (elem) {
            this.documentNumber(elem.value)
        },

        getPlaceOrderDeferredObject: function () {
            $('button.checkout').attr('disabled', 'disabled');
            return $.when(
                placeOrderAction(this.getData(), this.messageContainer)
            );
        },

        initQuoteListener: function () {
            let self = this;
        },

        initCurrentMethodListener: function () {
            let self = this;
            quote.paymentMethod.subscribe(function () {
                self.currentMethod(quote.paymentMethod().method);
            });
        },
        /**
         * @returns {String}
         */
        getCode: function () {
            return this.code;
        },

        /**
         * Get data
         * @returns {Object}
         */
        getData: function () {
            return {
                'method': this.item.method,
                'additional_data': {
                    'order_id': window.sessionStorage.klapOrderId
                }
            };
        },


        getAllowedMethods: function () {
            return CONFIG_PAYMENT.allowed_methods;
        },

        /**
         * @returns {String}
         */
        getTitle: function () {
            return !this.getLogo() ? CONFIG_PAYMENT.title : ''
        },
        /**
         * @returns {String}
         */
        getLogo: function () {
            return CONFIG_PAYMENT.logo
        },

        getMethodLogo: function (method) {
            return CONFIG_PAYMENT.methods_img_url[method].img
        },

        getOrderTotal: function () {
            return quote.totals()['grand_total'];
        }
    });
});
