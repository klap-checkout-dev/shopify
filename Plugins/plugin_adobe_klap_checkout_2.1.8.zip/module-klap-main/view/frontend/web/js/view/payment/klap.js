define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        const type = 'klap';
        const type_flex = 'klap_flex';
        if (window.checkoutConfig.payment[type].active ) {
            rendererList.push(
                {
                    type: type,
                    component: 'Improntus_Klap/js/view/payment/method-renderer/klap-method'
                }
            );
        }
        if (window.checkoutConfig.payment[type_flex].active ) {
            rendererList.push(
                {
                    type: type_flex,
                    component: 'Improntus_Klap/js/view/payment/method-renderer/klap-flex-method'
                }
            );
        }

        return Component.extend({});
    }
);
