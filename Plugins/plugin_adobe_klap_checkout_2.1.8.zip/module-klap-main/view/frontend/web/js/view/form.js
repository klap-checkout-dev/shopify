define([
    'ko',
    'uiComponent',
    'jquery',
    'Improntus_Klap/js/view/payment/method-renderer/cardForm/card-form'
], function (ko, Component, $, cardForm) {
    return Component.extend({
        cardType: ko.observable(null),
        orderId: ko.observable(null),
        creditCardHandler: null,
        initialize: function () {
            this._super();
            this.createKlapOrder();
            this.initApp();
        },

        initApp: function () {
            this.creditCardHandler = cardForm.init(this);
            window.creditCardHandler = this.creditCardHandler;
        },

        getUrl: function () {
            return `/rest/V1/klap/order/1/`;
        },

        createKlapOrder: function () {
            let self = this;
            $.ajax({
                url: this.getUrl(),
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    self.orderId(data);
                }, failure: function (data) {
                    self.orderId(null);
                }
            });
        },
    });
})
