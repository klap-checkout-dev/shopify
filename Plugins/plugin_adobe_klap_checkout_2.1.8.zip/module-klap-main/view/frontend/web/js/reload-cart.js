define(['Magento_Customer/js/customer-data'], function (customerData) {
  'use strict';

  return function () {
    customerData.getInitCustomerData().done(function () {
      customerData.reload(['cart'], false);
    });
  };
});
