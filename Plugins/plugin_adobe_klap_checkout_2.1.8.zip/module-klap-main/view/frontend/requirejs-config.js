var config = {
    map: {
        '*': {
            klap_form: 'Improntus_Klap/js/view/form',
        }
    }
};
