<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Improntus\Klap\ViewModel\Result;

use Magento\Framework;
use Magento\Framework\View;
use Magento\Framework\View\Page\Config\RendererFactory;
use Magento\Framework\View\Page\Layout\Reader;

class Page extends View\Result\Page
{
    /**
     * @var \Improntus\Klap\ViewModel\Page\Config\RendererFactory
     */
    protected $customPageConfigRendererFactory;

    /**
     * @param View\Element\Template\Context $context
     * @param View\LayoutFactory $layoutFactory
     * @param View\Layout\ReaderPool $layoutReaderPool
     * @param Framework\Translate\InlineInterface $translateInline
     * @param View\Layout\BuilderFactory $layoutBuilderFactory
     * @param View\Layout\GeneratorPool $generatorPool
     * @param \Improntus\Klap\ViewModel\Page\Config\RendererFactory $customPageConfigRendererFactory
     * @param RendererFactory $pageConfigRendererFactory
     * @param Reader $pageLayoutReader
     */
    public function __construct(
        View\Element\Template\Context                    $context,
        View\LayoutFactory                               $layoutFactory,
        View\Layout\ReaderPool                           $layoutReaderPool,
        Framework\Translate\InlineInterface              $translateInline,
        View\Layout\BuilderFactory                       $layoutBuilderFactory,
        View\Layout\GeneratorPool                        $generatorPool,
        \Improntus\Klap\ViewModel\Page\Config\RendererFactory $customPageConfigRendererFactory,
        View\Page\Config\RendererFactory                 $pageConfigRendererFactory,
        View\Page\Layout\Reader                          $pageLayoutReader
    ) {
        $this->customPageConfigRendererFactory = $customPageConfigRendererFactory;
        parent::__construct(
            $context,
            $layoutFactory,
            $layoutReaderPool,
            $translateInline,
            $layoutBuilderFactory,
            $generatorPool,
            $pageConfigRendererFactory,
            $pageLayoutReader,
            'Improntus_Klap::root.phtml'
        );
    }

    /**
     * Initialize page config reader
     *
     * @return void
     */
    protected function initPageConfigReader()
    {
        $this->pageConfigRenderer = $this->customPageConfigRendererFactory->create(['pageConfig' => $this->pageConfig]);
    }
}
