<?php

namespace Improntus\Klap\Cron;

use Magento\Framework\Exception\LocalizedException;
use Improntus\Klap\Model\KlapLogsRepository as KlapLogs;

/**
 * Cancel order class handles expired and canceled order cron
 */
class DeleteHistoricalLogs
{
    /**
     * @var KlapLogs
     */
    private $klapLogs;

    public function __construct(
        KlapLogs $klapLogs
    ) {
        $this->klapLogs = $klapLogs;
    }

    /**
     * Deletes the historical logs for maintenance
     * @throws LocalizedException
     */
    public function deleteLogs()
    {
        $this->klapLogs->deleteOlderLogs();
    }
}
