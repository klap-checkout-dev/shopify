<?php

namespace Improntus\Klap\Cron;

use Improntus\Klap\Api\TransactionRepositoryInterface;
use Improntus\Klap\Helper\Data;
use Improntus\Klap\Model\KlapOrder as Klap;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order\Collection as OrderCollection;
use Magento\Sales\Model\Order as SaleOrder;

/**
 * Cancel order class handles expired and canceled order cron
 */
class CancelOrder
{
    private const PENDING = 'pending';
    private const EXPIRED = 'expired';
    private const CANCELED = 'canceled';

    /**
     * @var SaleOrder
     */
    private $saleOrder;

    /**
     * @var Data
     */
    private $helper;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var TransactionRepositoryInterface
     */
    private $transactionRepository;

    /**
     * @var Klap
     */
    private $klap;

    public function __construct(
        TransactionRepositoryInterface $transactionRepository,
        OrderRepositoryInterface       $orderRepository,
        SaleOrder                      $saleOrder,
        Data                           $helper,
        Klap                           $klap
    ) {
        $this->saleOrder = $saleOrder;
        $this->helper = $helper;
        $this->orderRepository = $orderRepository;
        $this->klap = $klap;
        $this->transactionRepository = $transactionRepository;
    }

    /**
     * Handles canceling of orders pending that surpass the inactive tolerance configuration
     * @throws LocalizedException
     */
    public function cancelPending()
    {
        $collection = $this->klap->getOrderCollection(self::PENDING, "canc");
        $now = date_create(date('Y-m-d H:i:s', strtotime("now")));
        foreach ($collection as $order) {
            $createdAt = date_create($order->getCreatedAt());
            $interval = abs(($createdAt->getTimestamp() - $now->getTimestamp()) / 3600);
            $cancelHours = $this->helper->getCancelHours($order->getStore()->getId());
            if ($cancelHours == '') {
                $cancelHours = 24;
            }
            if ($order->getStatus() === Order::STATE_PAYMENT_REVIEW ||
                $interval < $cancelHours
            ) {
                continue;
            }
            $this->klap->updateExpiredTransaction($order->getQuoteId());
            $message = (__('Order canceled after ' . $cancelHours . ' hours pending.'));
            $this->klap->cancelOrder($order, $message);
        }
    }

    /**
     * Handles canceling of orders that were webhook rejected
     * @throws LocalizedException
     */
    public function cancelExpired()
    {
        $collection = $this->transactionRepository->getTransactionCollection(self::EXPIRED);
        foreach ($collection as $transaction) {
            if (!$transaction->getOrderId()) {
                $transaction->setOrderId($this->saleOrder->
                loadByAttribute('quote_id', $transaction->getQuoteId())->getId());
            }
            if (!$transaction->getOrderId()) {
                //This means the quote id did not generate an order, so we have nothing to cancel
                continue;
            }
            $order = $this->orderRepository->get($transaction->getOrderId());
            try {
                if (!$transaction->getExpiredAt()) {
                    continue;
                }
                $paymentMethod = $order->getPayment()->getMethod();
                if (!in_array($paymentMethod, ['klap', 'klap_flex'])) {
                    //If the quote was utilized by another entity, we cancel the expired transaction
                    $transaction->setStatus(strtoupper(self::CANCELED));
                    $this->transactionRepository->save($transaction);
                    continue;
                }
            } catch (\Exception $e) {
                // Order is not present
                continue;
            }

            if (!$transaction->getIncrementId()) {
                $transaction->setIncrementId($order->getIncrementId());
            }
            $timeZone = new \DateTimeZone('America/Santiago');
            $currentTime = date_create(date('Y-m-d H:i:s', strtotime("now")), $timeZone);
            $expiredAt = date_create(date('Y-m-d H:i:s', strtotime($transaction->getExpiredAt())), $timeZone);
            if ($expiredAt->format('Y-m-d H:i:s') < $currentTime->format('Y-m-d H:i:s')) {
                $message = (__('Order canceled due to expired notification.'));
                $message .= "| Klap Order Id: " . $transaction->getKlapTransactionId();
                $this->klap->cancelOrder($order, $message);
                $transaction->setStatus(strtoupper(self::CANCELED));
                $this->transactionRepository->save($transaction);
            }
        }
    }
}
