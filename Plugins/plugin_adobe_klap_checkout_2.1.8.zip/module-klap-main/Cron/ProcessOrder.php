<?php

namespace Improntus\Klap\Cron;

use Improntus\Klap\Model\KlapOrder as Klap;
use Improntus\Klap\Model\TransactionRepository as KlapTransaction;
use Magento\Framework\Stdlib\DateTime;

/**
 * ProcessOrder class handles transactions approved by webhooks
 */
class ProcessOrder
{
    private const PENDING = 'pending';

    /**
     * @var Klap
     */
    private $klap;

    /**
     * @var KlapTransaction
     */
    private $klapTransaction;

    /**
     * @var DateTime
     */
    private $dateTime;


    public function __construct(
        Klap            $klap,
        KlapTransaction $klapTransaction,
        DateTime        $dateTime
    ) {
        $this->klap = $klap;
        $this->klapTransaction = $klapTransaction;
        $this->dateTime = $dateTime;
    }

    /**
     * Main Cron job for processing APPROVED Klap transactions
     */
    public function processPending()
    {
        $collection = $this->klap->getOrderCollection(self::PENDING, "proc");
        foreach ($collection as $order) {
            $klapTransaction = $this->hasApprovedTransaction($order->getQuoteId());
            if (!$order->canInvoice() || $order->hasInvoices()
                || !$klapTransaction) {
                continue;
            }
            $date = $this->dateTime->formatDate($klapTransaction->getCreatedAt());
            $now = $this->dateTime->formatDate(true);
            $diff = strtotime($now) - strtotime($date);
            if ($diff <= 900) {
                //Add wait time for controller redirect
                continue;
            }
            $this->klap->processPending($order, $klapTransaction);
        }
    }

    /**
     * Returns klap_transaction row by quote id or false if not found
     * @param $quoteId
     * @return bool|\Improntus\Klap\Api\Data\TransactionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function hasApprovedTransaction($quoteId)
    {
        return $this->klapTransaction->getByQuoteId($quoteId);
    }
}
