CHANGELOG
---------

### 2.1.8

* Fix order comment when order is rejected during the creation of the order.

### 2.1.7

* Updated function to get Klap Order ID from KLAP API.
* Added is sandbox mode variable to the config provider.
* Added new policy rules.
* Delete old form-flex API init.
* Remove KLAP_FLEX.init empty to avoid twice call.
* Remove bind for data-bind blick on payment button.
* Update production URL to klap.cl.
* Added validation for origin of the postMessage to use only the messages coming from the trusted origin.

### 2.1.6

* Removed trusted domain validation for Klap API.

### 2.1.5

* Update CSP whitelist to include Klap's new domain.
    1. klap.cl
    1. pay.google.com

### 2.1.4

* Added events for validate order in mobile and place order in mobile.

### 2.1.3

* The event is updated from postMessage to place the order, to avoid problems with gpay and apple pay.

### 2.1.2

* Magento's use of modal is removed and instead Klap's useModal is used when performing the init.
* Updated the html template to remove the call to the function to generate modal.
* Removed the modal module in `klap-flex-method.js`.
* The origin of the postMessage is validated to use only the messages coming from the trusted origin.

### 2.1.1

* Added subscriber to the payment method to eliminate the beforeUnload event when the active payment method is not Klap Flex.
* Rename function `prevetReload` for `preventReload`. 

### 2.1.0

* Added JS with Klap API load.
* Removed extra iframe that existed and caused errors, keeping only the iframe by Klap API.
* Rebuilt `klap-flex-method.js`.
* Layouts, controller, templates that loaded the Klap API were removed.
* Controller, layout and template are created to failire page and to be able to perform a reload of the cart at the moment of the failure.
* `layout=“1column”` is removed from checkout_index_index.

### 2.0.10

* Fixed unload verification outside payment event
* Minor fixes to incoming messages

### 2.0.9

* Implemented header validation for incoming webhooks
* Refined modal styling for improved UI consistency
* Fixed runtime error caused by improper access to a constant during payment method retrieval
* Resolved incorrect namespace values in the integrated view

### 2.0.8

* Fixes a bug where the payment method was not correctly sent when checking for orders, which caused the endpoint to use the default value for environment.

### 2.0.7

* Adds quote restoration on failed purchase.

### 2.0.6

* Adds compatibility for async success webhook.

### 2.0.5

* Moves invoice processing to order generation if the order id is completed on Klap's WS.

### 2.0.4

* Adds validation for length on firstname and lastname required by Klap's backend.

### 2.0.3

* Fixes an issue using Agreements in manual mode not validating properly.

### 2.0.2

* Fixes an issue if ws is down and the quote is not reserved for other entities.
* Removes additional api key configuration.
* Minor translation fixes.

### 2.0.1

* Configuration added for merchant notification.

### 2.0.0

* Klap Flex

### 1.0.1

* Fixes Readme and Versions

### 1.0.0 (2024-07-10)

* Initial release
